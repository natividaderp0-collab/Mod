#pragma once
#include <algorithm>
#include <cmath>

namespace crimson::aim {
struct Point { float x{}, y{}; };
// Bones already validated by the ESP: head=6, neck=5, upper chest=4.
template<class Position, class Bones>
inline Position targetPosition(const Position& head, const Bones& bones, bool hasBones, int target) {
    int index = target == 1 ? 5 : target == 2 ? 4 : 6;
    if (hasBones) return bones[index];
    Position result=head;
    result.z -= target == 1 ? 7.f : target == 2 ? 18.f : 0.f;
    return result;
}
// Reduce gain after a correction crosses the aim point outside the dead zone.
struct AxisDamping {
    float previous{}, scale=1.f;
    bool hasPrevious{};
    float update(float error, float deadzone) {
        if (!std::isfinite(error) || !std::isfinite(deadzone) || deadzone<0) return 0.f;
        if (std::abs(error)<=deadzone) { hasPrevious=false; return 0.f; }
        if (hasPrevious && error*previous<0) scale=std::max(.125f,scale*.5f);
        previous=error; hasPrevious=true; return scale;
    }
    void reset() {previous=0;scale=1;hasPrevious=false;}
};
inline bool inRadius(Point p, float width, float height, float radius) {
    if (!(width > 0 && height > 0 && radius > 0) || !std::isfinite(p.x) || !std::isfinite(p.y)) return false;
    if (p.x < 0 || p.y < 0 || p.x > width || p.y > height) return false;
    const float dx=p.x-width/2, dy=p.y-height/2;
    return dx*dx+dy*dy <= radius*radius;
}
// Convert projected displacement to a relative mouse movement for the game's sensitivity.
inline Point mouseMove(Point p, float width, float height, float fx, float fy, float sensitivity, float smoothing, float gain=1.f) {
    if (!(width>0 && height>0 && fx>0.01f && fy>0.01f && sensitivity>0.01f && smoothing>=1 && gain>0 && std::isfinite(gain))) return {};
    constexpr float radToDeg=57.295779513f;
    const float scale=radToDeg*gain/(sensitivity*0.022f*smoothing);
    Point v{std::atan((p.x-width/2)*2/(width*fx))*scale,
            std::atan((p.y-height/2)*2/(height*fy))*scale};
    if(!std::isfinite(v.x)||!std::isfinite(v.y)) return {};
    return {std::clamp(v.x,-2048.f,2048.f),std::clamp(v.y,-2048.f,2048.f)};
}
inline Point recoilMove(Point previous, Point current, float sensitivity, float strength) {
    if (!(sensitivity>0.01f && strength>=0) || !std::isfinite(previous.x) || !std::isfinite(previous.y) || !std::isfinite(current.x) || !std::isfinite(current.y)) return {};
    const float scale=strength/(sensitivity*0.022f);
    return {std::clamp(-(current.y-previous.y)*scale,-80.f,80.f),std::clamp(-(current.x-previous.x)*scale,-80.f,80.f)};
}
}
