#pragma once
#include <algorithm>
#include <array>
#include <cmath>

namespace crimson::preview {
struct Point {float x{},y{};};
struct Pose {std::array<Point,28> bones{};float top{},bottom{};};
// Face the shoulders toward the viewer and fit the real pose to a fixed stage.
// Coordinates are relative to the preview canvas, not to the game screen.
template<class Bones>
inline bool layout(const Bones& bones,float width,float height,Pose& result){
    if(!std::isfinite(width)||!std::isfinite(height)||width<100||height<160)return false;
    constexpr std::array<int,17> ids={0,2,4,5,6,8,9,10,13,14,15,22,23,24,25,26,27};
    auto finite=[](const auto& v){return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z);};
    for(int i:ids)if(!finite(bones[i]))return false;
    const auto& root=bones[0];
    float axisX=bones[13].x-bones[8].x,axisY=bones[13].y-bones[8].y;
    const float length=std::hypot(axisX,axisY);
    if(!std::isfinite(length))return false;
    if(length<.01f){axisX=1;axisY=0;}else{axisX/=length;axisY/=length;}
    std::array<float,28> x{};
    float minX=0,maxX=0,minZ=root.z,maxZ=root.z;
    for(int i:ids){
        const auto& v=bones[i];
        if(std::abs(v.x-root.x)>150||std::abs(v.y-root.y)>150||std::abs(v.z-root.z)>150)return false;
        x[i]=(v.x-root.x)*axisX+(v.y-root.y)*axisY;
        minX=std::min(minX,x[i]);maxX=std::max(maxX,x[i]);minZ=std::min(minZ,v.z);maxZ=std::max(maxZ,v.z);
    }
    const float rangeZ=maxZ-minZ,rangeX=maxX-minX;
    if(rangeZ<15||rangeZ>150||rangeX>200)return false;
    const float scale=std::min((width-60.f)/std::max(80.f,rangeX+24.f),(height-100.f)/std::max(100.f,rangeZ+16.f));
    if(!(scale>0)||!std::isfinite(scale))return false;
    const float centerX=(minX+maxX)*.5f, bodyHeight=(rangeZ+16.f)*scale;
    const float base=(height+bodyHeight)*.5f+5.f;
    Pose output;
    output.top=base-bodyHeight;
    output.bottom=base;
    for(int i:ids)output.bones[i]={width*.5f+(x[i]-centerX)*scale,base-(bones[i].z-minZ+8.f)*scale};
    result=output;return true;
}
}
