// C++20 · main.cpp · Crimson external ESP · Windows x64 · MSVC + DirectX 11
#include "core.hpp"
#include "game_selection.hpp"
#include "aim_controller.hpp"
#include "key_binding.hpp"
#include "preview_pose.hpp"
#include "preview_model.hpp"
#include "preview_image.hpp"
#include "radar.hpp"
#include "indicator.hpp"
#include "preview_data.hpp"
#include <d3d11.h>
#include <dwmapi.h>
#include <shellapi.h>
#include <wincodec.h>
#include <imgui.h>
#include <imgui_impl_win32.h>
#include <imgui_impl_dx11.h>
#include <cstdio>

#pragma comment(lib, "windowscodecs.lib")
#pragma comment(lib, "ole32.lib")

using namespace crimson;
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND,UINT,WPARAM,LPARAM);
static ID3D11Device* device{};static ID3D11DeviceContext* context{};
static ImFont* regular{};static ImFont* titleFont{};static ImFont* smallFont{};
static HWND mainWindow{},overlayWindow{};static bool running=true;
static constexpr ImVec4 red{.95f,.16f,.24f,1},muted{.51f,.52f,.58f,1},white{.93f,.93f,.96f,1};

struct BannerTexture {
    ID3D11ShaderResourceView* srv{};
    int width{}, height{};
    void release() {
        if (srv) { srv->Release(); srv = nullptr; }
        width = 0; height = 0;
    }
};
static BannerTexture banner,previewAgent;

static bool loadTextureFromFile(ID3D11Device* dev, const fs::path& path, BannerTexture& out) {
    std::error_code ec;
    if (!fs::exists(path, ec)) return false;
    IWICImagingFactory* factory{};
    if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&factory)))) return false;
    IWICBitmapDecoder* decoder{};
    if (FAILED(factory->CreateDecoderFromFilename(path.c_str(), nullptr, GENERIC_READ, WICDecodeMetadataCacheOnDemand, &decoder))) {
        factory->Release(); return false;
    }
    IWICBitmapFrameDecode* frame{};
    if (FAILED(decoder->GetFrame(0, &frame))) {
        decoder->Release(); factory->Release(); return false;
    }
    IWICFormatConverter* converter{};
    if (FAILED(factory->CreateFormatConverter(&converter))) {
        frame->Release(); decoder->Release(); factory->Release(); return false;
    }
    if (FAILED(converter->Initialize(frame, GUID_WICPixelFormat32bppRGBA, WICBitmapDitherTypeNone, nullptr, 0.0, WICBitmapPaletteTypeCustom))) {
        converter->Release(); frame->Release(); decoder->Release(); factory->Release(); return false;
    }
    UINT w{}, h{};
    converter->GetSize(&w, &h);
    if (w == 0 || h == 0) {
        converter->Release(); frame->Release(); decoder->Release(); factory->Release(); return false;
    }
    std::vector<uint8_t> pixels(w * h * 4);
    if (FAILED(converter->CopyPixels(nullptr, w * 4, (UINT)pixels.size(), pixels.data()))) {
        converter->Release(); frame->Release(); decoder->Release(); factory->Release(); return false;
    }
    converter->Release(); frame->Release(); decoder->Release(); factory->Release();

    D3D11_TEXTURE2D_DESC desc{};
    desc.Width = w; desc.Height = h; desc.MipLevels = 1; desc.ArraySize = 1;
    desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    desc.SampleDesc.Count = 1;
    desc.Usage = D3D11_USAGE_DEFAULT;
    desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;

    D3D11_SUBRESOURCE_DATA initData{};
    initData.pSysMem = pixels.data();
    initData.SysMemPitch = w * 4;

    ID3D11Texture2D* tex{};
    if (FAILED(dev->CreateTexture2D(&desc, &initData, &tex))) return false;

    D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc{};
    srvDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
    srvDesc.Texture2D.MipLevels = 1;

    ID3D11ShaderResourceView* srv{};
    HRESULT hr = dev->CreateShaderResourceView(tex, &srvDesc, &srv);
    tex->Release();
    if (SUCCEEDED(hr) && srv) {
        out.release();
        out.srv = srv;
        out.width = (int)w;
        out.height = (int)h;
        return true;
    }
    return false;
}

static bool refreshBanner() {
    if (!device) return false;
    static const wchar_t* candidates[] = {
        L"banner.png", L"banner.jpg", L"banner.jpeg", L"banner.bmp",
        L"logo.png", L"logo.jpg", L"logo.bmp"
    };
    for (auto* name : candidates) {
        if (loadTextureFromFile(device, root() / name, banner)) return true;
        if (loadTextureFromFile(device, root().parent_path() / name, banner)) return true;
        if (loadTextureFromFile(device, fs::current_path() / name, banner)) return true;
    }
    return false;
}
static bool loadPreviewAgent(){
    const std::array<fs::path,2> candidates={root()/L"preview_agent.png",root().parent_path()/L"assets"/L"preview_agent.png"};
    for(const auto& path:candidates)if(loadTextureFromFile(device,path,previewAgent)){
        if(previewAgent.width==395 && previewAgent.height==700)return true;
        previewAgent.release();
    }
    return false;
}

struct Surface {
    HWND hwnd{};IDXGISwapChain* swap{};ID3D11RenderTargetView* target{};ImGuiContext* gui{};int width{},height{};
    bool init(HWND w,int x,int y){
        hwnd=w;width=x;height=y;IDXGIDevice* dx{};IDXGIAdapter* a{};IDXGIFactory* f{};
        if(FAILED(device->QueryInterface(IID_PPV_ARGS(&dx))))return false;
        HRESULT hr=dx->GetAdapter(&a);if(SUCCEEDED(hr))hr=a->GetParent(IID_PPV_ARGS(&f));
        DXGI_SWAP_CHAIN_DESC d{};d.BufferCount=2;d.BufferDesc.Width=x;d.BufferDesc.Height=y;d.BufferDesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;
        d.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;d.OutputWindow=w;d.SampleDesc.Count=1;d.Windowed=TRUE;d.SwapEffect=DXGI_SWAP_EFFECT_DISCARD;
        if(SUCCEEDED(hr))hr=f->CreateSwapChain(device,&d,&swap);if(f){f->MakeWindowAssociation(w,DXGI_MWA_NO_ALT_ENTER);f->Release();}if(a)a->Release();dx->Release();
        if(FAILED(hr)||!makeTarget())return false;
        gui=ImGui::CreateContext();ImGui::SetCurrentContext(gui);auto&io=ImGui::GetIO();io.IniFilename=nullptr;io.LogFilename=nullptr;
        ImFontConfig cfg;cfg.OversampleH=2;cfg.OversampleV=2;cfg.PixelSnapH=true;
        auto*font=io.Fonts->AddFontFromFileTTF("C:/Windows/Fonts/segoeui.ttf",17,&cfg,io.Fonts->GetGlyphRangesDefault());
        if(!font)font=io.Fonts->AddFontDefault();
        if(w==mainWindow){regular=font;titleFont=io.Fonts->AddFontFromFileTTF("C:/Windows/Fonts/segoeuib.ttf",30,&cfg);smallFont=io.Fonts->AddFontFromFileTTF("C:/Windows/Fonts/segoeui.ttf",14,&cfg);if(!titleFont)titleFont=regular;if(!smallFont)smallFont=regular;}
        ImGui_ImplWin32_Init(w);ImGui_ImplDX11_Init(device,context);return true;
    }
    bool makeTarget(){ID3D11Texture2D*b{};if(FAILED(swap->GetBuffer(0,IID_PPV_ARGS(&b))))return false;auto hr=device->CreateRenderTargetView(b,nullptr,&target);b->Release();return SUCCEEDED(hr);}
    bool resize(int w,int h){if(w<=0||h<=0)return false;if(w==width&&h==height)return true;context->OMSetRenderTargets(0,nullptr,nullptr);if(target){target->Release();target=nullptr;}width=w;height=h;return SUCCEEDED(swap->ResizeBuffers(0,w,h,DXGI_FORMAT_UNKNOWN,0))&&makeTarget();}
    void begin(){ImGui::SetCurrentContext(gui);ImGui_ImplDX11_NewFrame();ImGui_ImplWin32_NewFrame();ImGui::NewFrame();}
    void render(bool panel){ImGui::Render();float clear[4]={panel?.035f:0,panel?.035f:0,panel?.045f:0,panel?1.f:0};context->OMSetRenderTargets(1,&target,nullptr);context->ClearRenderTargetView(target,clear);ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());}
    void destroy(){if(gui){ImGui::SetCurrentContext(gui);ImGui_ImplDX11_Shutdown();ImGui_ImplWin32_Shutdown();ImGui::DestroyContext(gui);gui=nullptr;}if(target)target->Release();if(swap)swap->Release();target=nullptr;swap=nullptr;}
};
static Surface panel,overlay;
static LRESULT CALLBACK wndproc(HWND h,UINT msg,WPARAM w,LPARAM l){
    auto* s=h==mainWindow?&panel:&overlay;if(s->gui){ImGui::SetCurrentContext(s->gui);if(ImGui_ImplWin32_WndProcHandler(h,msg,w,l))return 1;}
    if(msg==WM_CLOSE){if(h==mainWindow)running=false;return 0;}
    if(msg==WM_DESTROY){if(h==mainWindow)running=false;return 0;}
    if(msg==WM_GETMINMAXINFO&&h==mainWindow){auto*i=(MINMAXINFO*)l;i->ptMinTrackSize={1080,780};return 0;}
    if(msg==WM_NCHITTEST&&h==overlayWindow)return HTTRANSPARENT;
    if(msg==WM_ERASEBKGND)return 1;
    if(msg==WM_SYSCOMMAND&&(w&0xFFF0)==SC_KEYMENU)return 0;
    return DefWindowProcW(h,msg,w,l);
}
static void theme(){
    auto&s=ImGui::GetStyle();s.WindowPadding={0,0};s.FramePadding={12,8};s.ItemSpacing={12,12};s.ItemInnerSpacing={8,5};s.WindowRounding=0;s.ChildRounding=12;s.FrameRounding=6;s.PopupRounding=8;s.GrabRounding=4;s.ScrollbarRounding=8;s.ScrollbarSize=5;s.WindowBorderSize=0;s.ChildBorderSize=1;
    auto*c=s.Colors;c[ImGuiCol_Text]=white;c[ImGuiCol_TextDisabled]=muted;c[ImGuiCol_WindowBg]={.035f,.035f,.045f,1};c[ImGuiCol_ChildBg]={.057f,.057f,.073f,1};c[ImGuiCol_Border]={.14f,.13f,.17f,1};c[ImGuiCol_FrameBg]={.10f,.10f,.13f,1};c[ImGuiCol_FrameBgHovered]={.17f,.09f,.12f,1};c[ImGuiCol_FrameBgActive]={.24f,.08f,.12f,1};c[ImGuiCol_CheckMark]=red;c[ImGuiCol_SliderGrab]=red;c[ImGuiCol_SliderGrabActive]={1,.3f,.36f,1};c[ImGuiCol_Button]={.18f,.075f,.10f,1};c[ImGuiCol_ButtonHovered]={.31f,.09f,.13f,1};c[ImGuiCol_ButtonActive]=red;c[ImGuiCol_Header]={.25f,.075f,.11f,1};c[ImGuiCol_HeaderHovered]={.32f,.09f,.13f,1};c[ImGuiCol_HeaderActive]=red;c[ImGuiCol_Separator]=c[ImGuiCol_Border];c[ImGuiCol_PopupBg]={.07f,.07f,.09f,1};c[ImGuiCol_ScrollbarBg]={0,0,0,0};c[ImGuiCol_ScrollbarGrab]={.28f,.12f,.16f,1};
}
static ImU32 color(const float* c,float alpha=1){return ImGui::ColorConvertFloat4ToU32({c[0],c[1],c[2],c[3]*alpha});}
static void label(ImDrawList*d,ImVec2 at,const std::string& t,ImU32 c,float size,bool centered=true){
    auto*f=ImGui::GetFont();auto dim=f->CalcTextSizeA(size,FLT_MAX,0,t.c_str());if(centered)at.x-=dim.x*.5f;
    d->AddText(f,size,{at.x+1,at.y+1},IM_COL32(8,8,12,230),t.c_str());d->AddText(f,size,at,c,t.c_str());
}
static constexpr std::array<std::pair<int,int>,16> links={{{6,5},{5,4},{4,2},{2,0},{4,8},{8,9},{9,10},{4,13},{13,14},{14,15},{0,22},{22,23},{23,24},{0,25},{25,26},{26,27}}};
struct Actor {ImVec2 feet{},top{},head{};std::array<ImVec2,28>b{};std::array<bool,28>valid{};std::array<ImVec2,8>corners{};bool cube{};};
static void actor(ImDrawList*d,const Player&p,const Actor&a,const Settings&s,ImVec2 viewport,bool preview=false,ImVec2 origin={0,0}){
    if(!preview&&(!s.enabled||(p.ally&&!s.allies)||(!p.ally&&!s.enemies)||p.meters>s.maxDistance))return;
    float h=a.feet.y-a.top.y;if(h<8||h>viewport.y*3)return;float w=h*.44f;float left=a.top.x-w*.5f,right=a.top.x+w*.5f;
    ImU32 c=color(p.ally?s.ally:s.enemy),dark=IM_COL32(9,9,14,235);ImVec2 tl{left,a.top.y},br{right,a.feet.y};
    if(s.fill)d->AddRectFilled(tl,br,color(p.ally?s.ally:s.enemy,s.fillAlpha),s.rounding);
    auto line=[&](ImVec2 x,ImVec2 y,ImU32 col,float thickness){if(s.outline)d->AddLine(x,y,dark,thickness+2);d->AddLine(x,y,col,thickness);};
    if(s.box){
        if(s.boxType==2&&a.cube){static const int edge[12][2]={{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};for(auto&e:edge)line(a.corners[e[0]],a.corners[e[1]],c,s.thickness);}
        else if(s.boxType==1){float x=w*.26f,y=h*.17f;for(float xx:{left,right})for(float yy:{a.top.y,a.feet.y}){line({xx,yy},{xx+(xx==left?x:-x),yy},c,s.thickness);line({xx,yy},{xx,yy+(yy==a.top.y?y:-y)},c,s.thickness);}}
        else{if(s.outline)d->AddRect({left-1,a.top.y-1},{right+1,a.feet.y+1},dark,s.rounding,0,s.thickness+2);d->AddRect(tl,br,c,s.rounding,0,s.thickness);}
    }
    if(s.skeleton)for(auto [x,y]:links)if(a.valid[x]&&a.valid[y])line(a.b[x],a.b[y],color(s.bonesColor),s.skeletonWidth);
    if(s.head){if(s.outline)d->AddCircle(a.head,s.headRadius,dark,20,s.thickness+2);d->AddCircle(a.head,s.headRadius,c,20,s.thickness);}
    if(s.names)label(d,{a.top.x,a.top.y-s.fontSize-6},p.name,IM_COL32(236,236,245,255),s.fontSize);
    if(s.health){float fill=std::clamp(p.health/100.f,0.f,1.f);d->AddRectFilled({left-8,a.top.y-1},{left-3,a.feet.y+1},dark);d->AddRectFilled({left-7,a.feet.y-h*fill},{left-4,a.feet.y},IM_COL32((int)(255*(1-fill)),(int)(200*fill+35),82,255));if(p.health<100&&!s.healthNumbers)label(d,{left-16,a.feet.y-h*fill-7},std::to_string(p.health),IM_COL32_WHITE,11);}
    if(s.healthNumbers)label(d,{right+7,a.top.y},std::to_string(std::clamp(p.health,0,1000))+" HP",IM_COL32(235,235,240,255),s.fontSize,false);
    if(s.armor){d->AddRectFilled({left,a.feet.y+4},{right,a.feet.y+7},dark);d->AddRectFilled({left,a.feet.y+4},{left+w*std::clamp(p.armor/100.f,0.f,1.f),a.feet.y+7},IM_COL32(90,155,235,255));}
    if(s.distance){char t[32];std::snprintf(t,sizeof t,"%.0f m",p.meters);label(d,{a.top.x,a.feet.y+(s.armor?12.f:6.f)},t,c,s.fontSize-1);}
    if(s.snaplines){float y=origin.y+(s.lineOrigin==0?0:s.lineOrigin==1?viewport.y*.5f:viewport.y);line({origin.x+viewport.x*.5f,y},a.feet,c,.9f);}
}
static void drawIndicator(ImDrawList*d,const indicator::Arrow& a,ImVec2 origin,ImU32 fill){
    auto pt=[&](indicator::Point p){return ImVec2{origin.x+p.x,origin.y+p.y};};
    d->AddTriangleFilled(pt(a.tip),pt(a.left),pt(a.right),fill);
    d->AddTriangle(pt(a.tip),pt(a.left),pt(a.right),IM_COL32(7,7,11,235),1.2f);
}
// Radar is a read-only map with fixed world axes, not a rotating minimap.
static void drawRadar(ImDrawList*d,const Snapshot&snap,const Settings&s,ImVec2 pos,float size,std::chrono::steady_clock::time_point now){
    float r=size*.5f-9.f;ImVec2 center{pos.x+size*.5f,pos.y+size*.5f};
    d->AddRectFilled(pos,{pos.x+size,pos.y+size},IM_COL32(11,12,18,220),8);
    d->AddRect(pos,{pos.x+size,pos.y+size},IM_COL32(113,80,94,205),8,0,1);
    d->AddCircle(center,r,IM_COL32(113,82,96,180),64,1);
    d->AddCircle(center,r*.5f,IM_COL32(100,81,94,95),64,1);
    d->AddLine({center.x-r,center.y},{center.x+r,center.y},IM_COL32(120,105,115,90));
    d->AddLine({center.x,center.y-r},{center.x,center.y+r},IM_COL32(120,105,115,90));
    for(const auto& marker:radar::markers(snap,s.radarRange,r-4.f,s.enemies,s.allies,now)){
        ImVec2 point{center.x+marker.position.x,center.y+marker.position.y};
        d->AddCircleFilled(point,4.f,IM_COL32(9,9,14,235),12);
        d->AddCircleFilled(point,2.6f,color(marker.ally?s.ally:s.enemy),12);
    }
    d->AddCircleFilled(center,3.3f,IM_COL32(246,246,250,255),12);
    if(!radar::available(snap,now))label(d,{center.x,pos.y+size-20},"AGUARDANDO LEITURA",IM_COL32(180,166,174,230),10);
    d->AddText({pos.x+9,pos.y+6},IM_COL32(212,190,198,230),"RADAR / XY");
}
static void drawReferenceCrosshair(ImDrawList*d,const Settings&s,ImVec2 size,ImVec2 origin={0,0}){
    ImVec2 c{origin.x+size.x*.5f,origin.y+size.y*.5f};float n=s.crosshairSize;
    const ImU32 dark=IM_COL32(0,0,0,230),light=IM_COL32(245,245,245,240);
    if(s.crosshairStyle==1){d->AddCircleFilled(c,n*.45f+1.5f,dark,20);d->AddCircleFilled(c,n*.45f,light,20);return;}
    auto line=[&](ImVec2 a,ImVec2 b){d->AddLine(a,b,dark,3.f);d->AddLine(a,b,light,1.f);};
    float gap=std::min(2.f,n*.35f);
    line({c.x-n,c.y},{c.x-gap,c.y});line({c.x+gap,c.y},{c.x+n,c.y});
    line({c.x,c.y-n},{c.x,c.y-gap});line({c.x,c.y+gap},{c.x,c.y+n});
}
static bool screenActor(const Player&p,const Snapshot&snap,float w,float h,Actor&a){
    Vec2 v;Vec3 top=p.head;top.z+=8;if(!project(p.origin,snap.matrix,w,h,v))return false;a.feet={v.x,v.y};if(!project(top,snap.matrix,w,h,v))return false;a.top={v.x,v.y};if(!project(p.head,snap.matrix,w,h,v))return false;a.head={v.x,v.y};
    if(p.hasBones)for(size_t i=0;i<28;++i){a.valid[i]=project(p.bones[i],snap.matrix,w,h,v);a.b[i]={v.x,v.y};}
    float z=top.z-p.origin.z;a.cube=true;for(int i=0;i<8;++i){Vec3 c=p.origin;c.x+=(i%4==0||i%4==3)?-16.f:16.f;c.y+=(i%4<2)?-16.f:16.f;c.z+=i<4?0:z;if(!project(c,snap.matrix,w,h,v))a.cube=false;a.corners[i]={v.x,v.y};}return true;
}
static bool gameRect(DWORD pid,RECT&result,HWND&game){
    struct Search{DWORD pid;HWND hwnd;};Search x{pid,nullptr};
    EnumWindows([](HWND h,LPARAM l)->BOOL{auto*x=(Search*)l;DWORD id{};GetWindowThreadProcessId(h,&id);if(id==x->pid&&IsWindowVisible(h)&&GetWindow(h,GW_OWNER)==nullptr){RECT r{};GetClientRect(h,&r);if(r.right>300&&r.bottom>200){x->hwnd=h;return FALSE;}}return TRUE;},(LPARAM)&x);
    game=x.hwnd;if(!game||IsIconic(game))return false;RECT r{};GetClientRect(game,&r);POINT p{0,0};ClientToScreen(game,&p);result={p.x,p.y,p.x+r.right,p.y+r.bottom};return true;
}
static bool toggle(const char*name,bool&value,const char*note=nullptr){
    ImGui::PushID(name);ImGui::BeginGroup();ImGui::TextUnformatted(name);if(note){ImGui::PushFont(smallFont);ImGui::TextColored(muted,"%s",note);ImGui::PopFont();}ImGui::EndGroup();
    float width=39,h=21;ImGui::SameLine(ImGui::GetWindowContentRegionMax().x-width);auto p=ImGui::GetCursorScreenPos();bool changed=ImGui::InvisibleButton("switch",{width,h});if(changed)value=!value;
    auto*d=ImGui::GetWindowDrawList();d->AddRectFilled(p,{p.x+width,p.y+h},value?IM_COL32(225,38,60,255):IM_COL32(49,49,61,255),h*.5f);d->AddCircleFilled({p.x+(value?width-h*.5f:h*.5f),p.y+h*.5f},7.5f,value?IM_COL32_WHITE:IM_COL32(150,151,167,255));ImGui::PopID();return changed;
}
static void heading(const char*name,const char*subtitle=nullptr){ImGui::PushFont(titleFont);ImGui::TextUnformatted(name);ImGui::PopFont();if(subtitle)ImGui::TextColored(muted,"%s",subtitle);ImGui::Spacing();}
static void cardStart(const char*id,float height=0){ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{20,18});ImGui::BeginChild(id,{0,height},ImGuiChildFlags_Borders|ImGuiChildFlags_AlwaysUseWindowPadding);}
static void cardEnd(){ImGui::EndChild();ImGui::PopStyleVar();}
static void section(const char*name){ImGui::TextColored({.91f,.54f,.58f,1},"%s",name);ImGui::Spacing();}
static void slider(const char*name,float&v,float low,float high,const char*format){ImGui::SetNextItemWidth(-1);ImGui::SliderFloat(name,&v,low,high,format);}
static void renderPreview(const Settings&s,const Player* player,int source,bool useImage){
    auto pos=ImGui::GetCursorScreenPos();auto size=ImGui::GetContentRegionAvail();
    if(size.x<1||size.y<1)return;
    ImGui::InvisibleButton("preview_canvas",size);auto*d=ImGui::GetWindowDrawList();
    ImVec2 end{pos.x+size.x,pos.y+size.y};
    d->AddRectFilled(pos,end,IM_COL32(12,12,18,255),8);
    d->AddRectFilledMultiColor(pos,end,IM_COL32(30,16,24,145),IM_COL32(14,13,20,40),IM_COL32(10,10,15,0),IM_COL32(17,12,18,100));
    for(float x=pos.x+24;x<end.x;x+=32)d->AddLine({x,pos.y},{x,end.y},IM_COL32(44,39,49,55));
    for(float y=pos.y+24;y<end.y;y+=32)d->AddLine({pos.x,y},{end.x,y},IM_COL32(44,39,49,55));
    d->AddRect(pos,end,IM_COL32(62,45,56,180),8);
    float cx=pos.x+size.x*.5f;Actor a;bool imageMode=false,live=false;
    preview_image::Layout imageLayout;
    if(useImage && previewAgent.srv && preview_image::layout(size.x,size.y,imageLayout)){
        imageMode=true;live=player!=nullptr;
        auto point=[&](preview_image::Point p){return ImVec2{pos.x+p.x,pos.y+p.y};};
        d->AddImage((ImTextureID)previewAgent.srv,point(imageLayout.imageTop),point(imageLayout.imageBottom));
        a.top=point(imageLayout.top);a.feet=point(imageLayout.feet);a.head=point(imageLayout.head);
        for(int i:preview3d::used){a.b[i]=point(imageLayout.bones[i]);a.valid[i]=true;}
    }else{
        preview3d::Joints joints;live=player && preview3d::orient(player->bones,joints);
        if(!live)joints=preview3d::example();
        preview3d::Scene scene;bool rendered=preview3d::project(joints,size.x,size.y,scene);
        if(!rendered && live){live=false;joints=preview3d::example();rendered=preview3d::project(joints,size.x,size.y,scene);}
        if(!rendered){label(d,{cx,pos.y+size.y*.5f},"Amplie a janela",IM_COL32(167,157,170,255),12);return;}
        d->AddEllipseFilled({cx,pos.y+scene.bottom+9},{(scene.bottom-scene.top)*.24f,8},IM_COL32(228,38,58,26));
        for(const auto& face:scene.faces){
            ImVec2 vertices[4];for(int i=0;i<4;++i)vertices[i]={pos.x+face.points[i].x,pos.y+face.points[i].y};
            ImVec4 shade{face.material.r*face.light,face.material.g*face.light,face.material.b*face.light,1.f};
            d->AddConvexPolyFilled(vertices,4,ImGui::ColorConvertFloat4ToU32(shade));
            d->AddPolyline(vertices,4,IM_COL32(8,11,14,115),ImDrawFlags_Closed,.6f);
        }
        a.top={cx,pos.y+scene.top};a.feet={cx,pos.y+scene.bottom};
        for(int i:preview3d::used){a.b[i]={pos.x+scene.joints[i].x,pos.y+scene.joints[i].y};a.valid[i]=true;}
        a.head=a.b[6];
    }
    float bodyHeight=a.feet.y-a.top.y;a.cube=true;float ww=bodyHeight*.22f,dd=std::min(18.f,bodyHeight*.06f);
    for(int i=0;i<8;++i){bool upper=i>=4;int j=i%4;a.corners[i]={a.top.x+((j==0||j==3)?-ww:ww)+(j>=2?dd:-dd),upper?a.top.y+(j>=2?-8.f:8.f):a.feet.y+(j>=2?-8.f:8.f)};}
    Player sample;sample.name="Exemplo";sample.health=84;sample.armor=72;sample.meters=21;sample.ally=source!=0;
    d->PushClipRect(pos,end,true);
    actor(d,live?*player:sample,a,s,size,true,pos);
    if(s.offscreenArrows){
        const Matrix demonstration={1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1};indicator::Arrow arrow;
        if(indicator::offscreen(Vec3{2.f,0,0},demonstration,size.x,size.y,arrow))drawIndicator(d,arrow,pos,color(s.enemy));
    }
    d->PopClipRect();
    d->AddCircleFilled({pos.x+16,pos.y+17},3,live?IM_COL32(94,211,138,255):IM_COL32(207,167,98,255),12);
    const char* display=imageMode?"IMAGEM FIXA / AVA":(useImage?"IMAGEM INDISPONÍVEL":(live?"POSE EM TEMPO REAL":"POSE FIXA / EXEMPLO"));
    d->AddText({pos.x+25,pos.y+10},IM_COL32(205,188,158,255),display);
    label(d,{cx,end.y-18},imageMode?"AGENTE AVA / IMAGEM":"MODELO 3D GENÉRICO",IM_COL32(133,124,136,255),11);
}
static void gameSelector(games::Preference& preference, const games::Detection& detected) {
    int value = static_cast<int>(preference);
    const float selectorX = ImGui::GetCursorPosX();
    ImGui::SetNextItemWidth(166);
    if (ImGui::Combo("##selected_game", &value, "Automático\0CS2\0Arma Reforger\0"))
        preference = static_cast<games::Preference>(value);
    ImGui::SetCursorPosX(selectorX);
    ImGui::PushFont(smallFont);
    if (!detected.available) ImGui::TextColored(muted,"Detecção indisponível");
    else if (detected.cs2 && detected.reforger) ImGui::TextColored(muted,"Ambos encontrados");
    else if (detected.cs2) ImGui::TextColored(muted,"CS2 encontrado");
    else if (detected.reforger) ImGui::TextColored(muted,"Arma encontrado");
    else ImGui::TextColored(muted,"Nenhum jogo aberto");
    ImGui::PopFont();
}

static void reforgerUi(games::Preference& preference, const games::Detection& detected) {
    auto size=ImGui::GetIO().DisplaySize;
    ImGui::SetNextWindowPos({0,0}); ImGui::SetNextWindowSize(size);
    ImGui::Begin("lampião menu",nullptr,ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings);
    auto* d=ImGui::GetWindowDrawList();
    d->AddRectFilled({0,0},{196,size.y},IM_COL32(13,12,17,255));
    d->AddLine({196,0},{196,size.y},IM_COL32(46,26,35,255));
    d->AddRectFilledMultiColor({196,0},{size.x,130},IM_COL32(48,15,24,100),IM_COL32(14,14,19,0),IM_COL32(14,14,19,0),IM_COL32(14,14,19,0));
    ImGui::SetCursorPos({22,26}); ImGui::PushFont(titleFont); ImGui::TextColored(red,"lampião"); ImGui::PopFont();
    ImGui::SetCursorPos({24,70}); ImGui::PushFont(smallFont); ImGui::TextColored(muted,"SELECIONE O JOGO"); ImGui::PopFont();
    ImGui::SetCursorPos({15,96}); gameSelector(preference,detected);
    ImGui::SetCursorPos({24,size.y-100}); ImGui::PushFont(smallFont);
    ImGui::TextColored(muted,"INSERT  painel"); ImGui::SetCursorPosX(24); ImGui::TextColored(muted,"END  sair"); ImGui::PopFont();
    ImGui::SetCursorPos({222,28}); ImGui::PushFont(smallFont); ImGui::TextColored(red,"JOGOS / ARMA REFORGER"); ImGui::PopFont();
    ImGui::SetCursorPos({222,55}); ImGui::PushFont(titleFont); ImGui::TextUnformatted("Arma Reforger"); ImGui::PopFont();
    ImGui::SetCursorPos({222,115});
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{20,18});
    ImGui::BeginChild("reforger_status",{size.x-248,230},ImGuiChildFlags_Borders|ImGuiChildFlags_AlwaysUseWindowPadding);
    section("ESTADO DO JOGO");
    if (!detected.available) ImGui::TextWrapped("Não foi possível listar os processos (Windows %lu).",detected.error);
    else if (detected.reforger) ImGui::TextColored({.36f,.86f,.61f,1},"Arma Reforger encontrado");
    else ImGui::TextColored(muted,"Arma Reforger não encontrado");
    ImGui::Spacing(); ImGui::Separator(); ImGui::Spacing();
    ImGui::TextUnformatted("Integração em desenvolvimento");
    ImGui::TextWrapped("ESP, mira e radar do Arma ainda não estão disponíveis. Precisamos validar o acesso e os dados desta versão do jogo.");
    ImGui::Spacing(); ImGui::TextWrapped("O CS2 continua disponível no seletor de jogo.");
    ImGui::EndChild(); ImGui::PopStyleVar();
    ImGui::SetCursorPos({222,size.y-32}); ImGui::PushFont(smallFont); ImGui::TextColored(muted,"LAMPIÃO MENU  /  ARMA REFORGER  /  AGUARDANDO INTEGRAÇÃO"); ImGui::PopFont();
    ImGui::End();
}

static void ui(Settings&s,const Snapshot&snap,int&tab,std::string&toast,const AimController& aimController,KeyBindingCapture& binding,games::Preference& preference,const games::Detection& detected){
    auto display=ImGui::GetIO().DisplaySize;ImGui::SetNextWindowPos({0,0});ImGui::SetNextWindowSize(display);
    ImGui::Begin("lampião menu",nullptr,ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings);
    auto*d=ImGui::GetWindowDrawList();d->AddRectFilled({0,0},{196,display.y},IM_COL32(13,12,17,255));d->AddLine({196,0},{196,display.y},IM_COL32(46,26,35,255));
    d->AddRectFilledMultiColor({196,0},{display.x,130},IM_COL32(48,15,24,100),IM_COL32(14,14,19,0),IM_COL32(14,14,19,0),IM_COL32(14,14,19,0));
    float bannerH=0.f;
    if(banner.srv&&banner.width>0&&banner.height>0){
        float maxW=168.f,maxH=70.f;
        float scale=std::min(maxW/(float)banner.width,maxH/(float)banner.height);
        float bw=banner.width*scale,bh=banner.height*scale;
        float bx=14.f+(maxW-bw)*.5f;
        ImGui::SetCursorPos({bx,14.f});
        ImGui::Image((ImTextureID)banner.srv,{bw,bh});
        bannerH=bh+8.f;
    }else{
        d->AddRectFilled({14,14},{182,66},IM_COL32(24,16,22,230),8);
        d->AddRect({14,14},{182,66},IM_COL32(225,38,60,180),8,0,1.2f);
        label(d,{98,24},"LAMPIÃO",IM_COL32(250,250,255,255),15);
        label(d,{98,42},"BANNER (banner.png)",IM_COL32(240,70,90,255),10);
        bannerH=56.f;
    }
    float titleY=14.f+bannerH+4.f;
    ImGui::SetCursorPos({22,titleY});ImGui::PushFont(titleFont);ImGui::TextColored(red,"lampião");ImGui::SameLine();ImGui::TextUnformatted("menu");ImGui::PopFont();
    ImGui::SetCursorPos({25,titleY+32.f});ImGui::PushFont(smallFont);ImGui::TextColored(muted,"SELECIONE O JOGO");ImGui::PopFont();
    ImGui::SetCursorPos({15,titleY+52.f});gameSelector(preference,detected);
    const char* tabs[]={"01   ESP","02   Mira","03   Radar & treino","04   Aparência"};
    float tabsStartY=titleY+112.f;
    for(int i=0;i<4;++i){
        float ty=(i==3)?(display.y-180.f):(tabsStartY+i*44.f);
        if(i==3){
            d->AddLine({20,ty-12.f},{176,ty-12.f},IM_COL32(50,30,42,160));
        }
        ImGui::SetCursorPos({14,ty});
        if(tab==i){
            d->AddRectFilled({0,ty+6.f},{3,ty+35.f},IM_COL32(242,40,62,255),2);
            ImGui::PushStyleColor(ImGuiCol_Button,{.23f,.07f,.105f,1});
            ImGui::PushStyleColor(ImGuiCol_Text,{1,.55f,.59f,1});
        }else{
            ImGui::PushStyleColor(ImGuiCol_Button,{0,0,0,0});
            ImGui::PushStyleColor(ImGuiCol_Text,muted);
        }
        if(ImGui::Button(tabs[i],{168,40})){if(tab!=i)binding.cancel();tab=i;}
        ImGui::PopStyleColor(2);
    }
    ImGui::SetCursorPos({24,display.y-121});ImGui::BeginGroup();ImGui::PushFont(smallFont);ImGui::TextColored(red,"TREINAMENTO LOCAL");ImGui::TextColored(muted,snap.insecure?"-insecure":"padrão");ImGui::Spacing();ImGui::TextColored(muted,"INSERT  painel");ImGui::TextColored(muted,"F6  ESP    END  sair");ImGui::PopFont();ImGui::EndGroup();
    float contentX=222,contentW=display.x-contentX-26;ImGui::SetCursorPos({contentX,25});
    ImGui::PushFont(smallFont);ImGui::TextColored(red,"VISÃO TÁTICA / PERSONALIZAÇÃO");ImGui::PopFont();
    ImGui::SetCursorPos({contentX,48});ImGui::PushFont(titleFont);ImGui::TextUnformatted("Seu campo. Sua visão.");ImGui::PopFont();
    ImGui::SetCursorPos({contentX,88});ImGui::TextColored(muted,"Controle visual completo para suas sessões de treinamento.");
    ImGui::SetCursorPos({display.x-247,30});ImGui::PushStyleColor(ImGuiCol_Button,s.enabled?ImVec4{.72f,.10f,.18f,1}:ImVec4{.13f,.11f,.15f,1});if(ImGui::Button(s.enabled?"ESP ATIVO   /   F6":"ATIVAR ESP   /   F6",{220,38})){s.enabled=!s.enabled;}ImGui::PopStyleColor();
    ImGui::SetCursorPos({display.x-247,79});ImGui::PushFont(smallFont);ImGui::TextColored(snap.connected?ImVec4{.36f,.86f,.61f,1}:muted,"%s",snap.status.c_str());ImGui::PopFont();
    float mainW=contentW*.59f,previewW=contentW-mainW-18;float bodyY=133,bodyH=display.y-bodyY-48;
    ImGui::SetCursorPos({contentX,bodyY});ImGui::BeginChild("controls",{mainW,bodyH});
    if(tab==0){
        cardStart("targets",179);section("ALVOS");toggle("Inimigos",s.enemies,"Destaque dos jogadores da equipe adversária");toggle("Aliados",s.allies,"Identificação da sua equipe");cardEnd();
        cardStart("elements",0);section("ELEMENTOS DO ESP");toggle("Box",s.box);toggle("Esqueleto",s.skeleton);toggle("Nome do jogador",s.names);toggle("Barra de vida",s.health);toggle("Vida em número",s.healthNumbers);toggle("Barra de colete",s.armor);toggle("Distância",s.distance);toggle("Marcador de cabeça",s.head);toggle("Linhas de posição",s.snaplines);toggle("Setas fora da tela",s.offscreenArrows,"Inimigos à frente da câmera");ImGui::Separator();slider("##range",s.maxDistance,5,500,"Alcance   %.0f m");cardEnd();
    }else if(tab==1){
        cardStart("aim_controls",0);section("MIRA");
        toggle("Aimbot",s.aimEnabled,"Segure a tecla de ativação no jogo");
        ImGui::TextColored(muted,"PARTE DO CORPO");ImGui::SetNextItemWidth(-1);ImGui::Combo("##aim_target",&s.aimTarget,"Cabeça\0Pescoço\0Peito\0");
        ImGui::TextColored(muted,"PRIORIDADE DE ALVO");ImGui::SetNextItemWidth(-1);ImGui::Combo("##aim_priority",&s.aimPriority,"Mais perto do centro\0Mais perto de você\0");
        ImGui::TextColored(muted,"Com estabilização, o alvo fica preso até soltar a tecla.");
        ImGui::TextColored(muted,"TECLA DE ATIVAÇÃO");
        ImGui::Text("Atual: %s",keyName(s.aimVk).c_str());
        if(!binding.active){if(ImGui::Button("Alterar tecla",{-1,32}))binding.begin();}
        else {
            ImGui::TextWrapped("Solte as teclas e pressione a nova tecla ou botão. Para o mouse esquerdo, clique numa área vazia.");
            bool cancelled=ImGui::Button("Cancelar captura",{-1,32});
            binding.ignoreLeft=ImGui::IsItemHovered();
            if(cancelled)binding.cancel();
        }
        toggle("Mostrar círculo FOV",s.showFov);
        slider("##aim_radius",s.aimRadius,10,600,"Raio do FOV   %.0f px");
        slider("##aim_smooth",s.aimSmooth,1,30,"Suavidade   %.0f");
        slider("##aim_sensitivity",s.aimSensitivity,.1f,10.f,"Sensibilidade do CS2   %.2f");
        slider("##aim_gain",s.aimGain,.25f,12.f,"Força da mira   %.2fx");
        toggle("Estabilizar mira",s.aimStabilize,"Mantém o alvo e reduz oscilações");
        if(s.aimStabilize)slider("##aim_deadzone",s.aimDeadzone,0.f,12.f,"Zona sem correção   %.0f px");
        ImGui::Separator();section("RECUO");
        toggle("Compensar recuo",s.recoilEnabled,"Ativo enquanto o botão esquerdo estiver pressionado");
        slider("##recoil_strength",s.recoilStrength,0,2,"Intensidade   %.2f");
        ImGui::TextWrapped("Última tentativa: %s",aimController.status().c_str());
        ImGui::TextWrapped("Use a mesma sensibilidade configurada no CS2. A compensação depende da versão do jogo; a dispersão da arma continua.");
        ImGui::TextColored(snap.recoilReady?ImVec4{.36f,.86f,.61f,1}:muted,"Dados de recuo: %s",snap.recoilReady?"disponíveis":"indisponíveis");
        cardEnd();
    }else if(tab==2){
        cardStart("training_controls",0);section("RADAR 2D");
        toggle("Mostrar radar",s.radarEnabled,"Ative o ESP com F6 para usar no jogo");
        slider("##radar_range",s.radarRange,10,300,"Alcance do radar   %.0f m");
        slider("##radar_size",s.radarSize,120,300,"Tamanho do radar   %.0f px");
        ImGui::TextWrapped("Mapa de eixos fixos: o ponto branco é você. As cores seguem os filtros e as cores do ESP.");
        ImGui::TextColored(muted,"PRÉVIA COM DADOS DE EXEMPLO");
        Snapshot demo;demo.ready=true;demo.localAlive=true;demo.localPlayer=Player{};demo.sampled=std::chrono::steady_clock::now();
        Player e;e.origin={1200,900,0};demo.players.push_back(e);e.origin={-1600,-500,0};demo.players.push_back(e);
        e.ally=true;e.origin={-1100,1300,0};demo.players.push_back(e);
        auto pos=ImGui::GetCursorScreenPos();float demoSize=std::min(200.f,s.radarSize);
        drawRadar(ImGui::GetWindowDrawList(),demo,s,pos,demoSize,demo.sampled);ImGui::Dummy({demoSize,demoSize});
        ImGui::Separator();section("MIRA DE REFERÊNCIA");
        toggle("Mostrar mira de referência",s.referenceCrosshair,"Desenho no centro da tela");
        ImGui::TextColored(muted,"FORMATO");ImGui::SetNextItemWidth(-1);ImGui::Combo("##crosshair_style",&s.crosshairStyle,"Cruz\0Ponto\0");
        slider("##crosshair_size",s.crosshairSize,2.f,18.f,"Tamanho da mira   %.0f px");
        ImGui::TextColored(muted,"PRÉVIA DA MIRA");
        auto crossPos=ImGui::GetCursorScreenPos();ImVec2 crossSize{160,62};
        auto* crossDraw=ImGui::GetWindowDrawList();crossDraw->AddRectFilled(crossPos,{crossPos.x+crossSize.x,crossPos.y+crossSize.y},IM_COL32(13,13,19,255),6);
        drawReferenceCrosshair(crossDraw,s,crossSize,crossPos);ImGui::Dummy(crossSize);
        ImGui::TextWrapped("A mira de referência é visual e não muda os tiros do jogo.");
        cardEnd();
    }else{
        cardStart("appearance_combined",0);
        heading("Aparência & Configurações","Aparência, Cores, Perfis e Diagnóstico reunidos em uma só aba.");
        if(ImGui::BeginTabBar("settings_tab_bar",ImGuiTabBarFlags_FittingPolicyResizeDown)){
            if(ImGui::BeginTabItem("Aparência")){
                section("BANNER & IDENTIDADE");
                if(banner.srv&&banner.width>0) ImGui::TextColored({.36f,.86f,.61f,1},"Banner ativo: %dx%d px",banner.width,banner.height);
                else ImGui::TextColored(muted,"Nenhum banner encontrado (coloque banner.png na pasta)");
                if(ImGui::Button("Recarregar Banner",{170,30})){
                    if(refreshBanner()) toast="Banner recarregado com sucesso!";
                    else toast="banner.png nao encontrado na pasta";
                }
                ImGui::Separator();
                section("ESTILO DA BOX & OVERLAY");
                ImGui::TextColored(muted,"ESTILO DA BOX");ImGui::SetNextItemWidth(-1);ImGui::Combo("##box",&s.boxType,"Retângulo 2D\0Cantos\0Volume 3D\0");
                slider("##thickness",s.thickness,.5f,4,"Espessura da box   %.1f px");slider("##skeleton",s.skeletonWidth,.5f,4,"Espessura do esqueleto   %.1f px");slider("##round",s.rounding,0,12,"Arredondamento   %.0f px");slider("##font",s.fontSize,10,22,"Tamanho do texto   %.0f px");slider("##head",s.headRadius,1,12,"Raio da cabeça   %.0f px");
                toggle("Contorno de contraste",s.outline);toggle("Preenchimento da box",s.fill);if(s.fill)slider("##alpha",s.fillAlpha,0,.6f,"Opacidade do preenchimento   %.2f");
                ImGui::TextColored(muted,"ORIGEM DAS LINHAS");ImGui::SetNextItemWidth(-1);ImGui::Combo("##origin",&s.lineOrigin,"Topo\0Centro\0Base\0");toggle("Marca no overlay",s.watermark);
                ImGui::EndTabItem();
            }
            if(ImGui::BeginTabItem("Cores")){
                section("PALETA DE COMBATE");
                ImGui::TextColored(muted,"INIMIGOS");ImGui::ColorEdit4("##enemy",s.enemy,ImGuiColorEditFlags_AlphaBar|ImGuiColorEditFlags_DisplayRGB);ImGui::Spacing();
                ImGui::TextColored(muted,"ALIADOS");ImGui::ColorEdit4("##ally",s.ally,ImGuiColorEditFlags_AlphaBar|ImGuiColorEditFlags_DisplayRGB);ImGui::Spacing();
                ImGui::TextColored(muted,"ESQUELETO");ImGui::ColorEdit4("##bones",s.bonesColor,ImGuiColorEditFlags_AlphaBar|ImGuiColorEditFlags_DisplayRGB);ImGui::Spacing();
                ImGui::TextWrapped("As cores de equipe são aplicadas às boxes, cabeça, distância e linhas. O esqueleto tem uma cor própria.");ImGui::Spacing();
                if(ImGui::Button("Restaurar paleta padrão",{-1,36})){Settings defaults;std::copy_n(defaults.enemy,4,s.enemy);std::copy_n(defaults.ally,4,s.ally);std::copy_n(defaults.bonesColor,4,s.bonesColor);}
                ImGui::EndTabItem();
            }
            if(ImGui::BeginTabItem("Perfis")){
                section("PERFIS DE CONFIGURAÇÃO");
                for(int i=1;i<=3;++i){ImGui::PushID(i);ImGui::Text("PERFIL 0%d",i);auto path=root()/(L"perfil_"+std::to_wstring(i)+L".ini");if(ImGui::Button("Salvar",{130,36})){try{s.save(path);toast="Perfil "+std::to_string(i)+" salvo";}catch(const std::exception&e){toast=e.what();}}ImGui::SameLine();if(ImGui::Button("Carregar",{130,36}))toast=s.load(path)?"Perfil carregado":"Perfil ausente ou inválido";ImGui::Separator();ImGui::PopID();}
                ImGui::Spacing();section("PREDEFINIÇÕES");
                if(ImGui::Button("Essencial",{-1,35})){bool on=s.enabled;s=Settings{};s.enabled=on;s.skeleton=false;s.head=false;s.distance=false;s.allies=false;toast="Predefinição Essencial aplicada";}
                if(ImGui::Button("Completo",{-1,35})){bool on=s.enabled;s=Settings{};s.enabled=on;s.armor=true;s.fill=true;s.snaplines=true;toast="Predefinição Completo aplicada";}
                if(ImGui::Button("Restaurar padrão",{-1,35})){s=Settings{};toast="Padrão restaurado";}
                ImGui::EndTabItem();
            }
            if(ImGui::BeginTabItem("Diagnóstico")){
                section("CONEXÃO E LEITURA");
                ImGui::TextColored(red,"%s",snap.status.c_str());ImGui::TextWrapped("%s",snap.detail.c_str());ImGui::Separator();
                ImGui::Text("Processo: %lu",snap.pid);ImGui::Text("Parâmetro -insecure: %s",snap.insecure?"verificado":(REQUIRE_INSECURE?"aguardando":"desabilitado / opcional"));ImGui::Text("PE timestamp: %08X",snap.timestamp);ImGui::Text("Entidades válidas: %zu",snap.players.size());ImGui::Text("Leitura: %.2f ms",snap.readMs);ImGui::Text("Passo de entidade: 0x%X",snap.stride);
                if(snap.boneOffset>=0)ImGui::Text("Bones / model state: +0x%X",snap.boneOffset);else ImGui::TextColored(muted,"Bones: aguardando validação em partida");
                ImGui::Separator();ImGui::TextWrapped("Os offsets são extraídos do client.dll desta instalação. O arquivo offsets_local.json registra os valores e a identidade da DLL.");ImGui::Spacing();
                ImGui::SetNextItemWidth(-1);ImGui::SliderInt("##fps",&s.fps,30,240,"Limite do overlay: %d FPS");ImGui::Spacing();
                ImGui::TextWrapped("Use o CS2 em janela sem bordas. INSERT mostra ou oculta este painel; F6 liga ou pausa o ESP; END encerra o aplicativo.");
                ImGui::EndTabItem();
            }
            ImGui::EndTabBar();
        }
        cardEnd();
    }
    ImGui::EndChild();
    ImGui::SetCursorPos({contentX+mainW+18,bodyY});ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{18,18});ImGui::BeginChild("livepreview",{previewW,bodyH},ImGuiChildFlags_Borders|ImGuiChildFlags_AlwaysUseWindowPadding);
    ImGui::TextUnformatted("PRÉVIA DO ESP");
    static int previewSource=0,previewVisual=0;static uint64_t previewPawn=0;
    ImGui::SetNextItemWidth(-1);if(ImGui::Combo("##previewteam",&previewSource,"Inimigo\0Aliado\0Meu personagem\0"))previewPawn=0;
    ImGui::SetNextItemWidth(-1);ImGui::Combo("##previewvisual",&previewVisual,"Imagem fixa / Ava\0Modelo por ossos\0");
    auto result=preview::inspect(snap,previewSource,previewPawn,std::chrono::steady_clock::now());
    const Player* live=result.player;preview3d::Joints poseCheck;
    bool validPose=live && preview3d::orient(live->bones,poseCheck);
    const char* previewStatus=previewVisual==0 && previewAgent.srv && live?"Dados do jogador disponíveis":(live&&!validPose?"Pose inválida para prévia":preview::message(result.status));
    ImGui::PushFont(smallFont);ImGui::TextColored((previewVisual==0?live!=nullptr:validPose)?ImVec4{.36f,.86f,.61f,1}:muted,"%s",previewStatus);ImGui::PopFont();
    renderPreview(s,live,previewSource,previewVisual==0);ImGui::EndChild();ImGui::PopStyleVar();
    ImGui::SetCursorPos({contentX,display.y-32});ImGui::PushFont(smallFont);if(!toast.empty())ImGui::TextColored({.85f,.66f,.68f,1},"%s",toast.c_str());else ImGui::TextColored(muted,"LAMPIÃO MENU 1.0     /     DX11     /     %s",snap.connected?"CONECTADO":"DESCONECTADO");ImGui::PopFont();ImGui::End();
}
static bool capture(Surface&s,const fs::path&path){
    ID3D11Texture2D*source{};if(FAILED(s.swap->GetBuffer(0,IID_PPV_ARGS(&source))))return false;D3D11_TEXTURE2D_DESC desc{};source->GetDesc(&desc);desc.Usage=D3D11_USAGE_STAGING;desc.BindFlags=0;desc.CPUAccessFlags=D3D11_CPU_ACCESS_READ;desc.MiscFlags=0;
    ID3D11Texture2D*staging{};auto hr=device->CreateTexture2D(&desc,nullptr,&staging);if(FAILED(hr)){source->Release();return false;}context->CopyResource(staging,source);D3D11_MAPPED_SUBRESOURCE m{};hr=context->Map(staging,0,D3D11_MAP_READ,0,&m);
    if(SUCCEEDED(hr)){BITMAPFILEHEADER file{};BITMAPINFOHEADER info{};file.bfType=0x4D42;file.bfOffBits=sizeof file+sizeof info;file.bfSize=file.bfOffBits+desc.Width*desc.Height*4;info.biSize=sizeof info;info.biWidth=desc.Width;info.biHeight=-(LONG)desc.Height;info.biPlanes=1;info.biBitCount=32;info.biCompression=BI_RGB;
        std::ofstream f(path,std::ios::binary);f.write((char*)&file,sizeof file);f.write((char*)&info,sizeof info);std::vector<uint8_t>row(desc.Width*4);
        for(UINT y=0;y<desc.Height;++y){auto*p=(uint8_t*)m.pData+y*m.RowPitch;for(UINT x=0;x<desc.Width;++x){row[x*4]=p[x*4+2];row[x*4+1]=p[x*4+1];row[x*4+2]=p[x*4];row[x*4+3]=255;}f.write((char*)row.data(),row.size());}context->Unmap(staging,0);hr=f?S_OK:E_FAIL;
    }staging->Release();source->Release();return SUCCEEDED(hr);
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE,PWSTR command,int){
    SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    Handle single(CreateMutexW(nullptr,FALSE,L"Local\\LampiaoMenu.Panel.v1"));if(GetLastError()==ERROR_ALREADY_EXISTS){if(auto w=FindWindowW(L"LampiaoMain",nullptr)){ShowWindow(w,SW_RESTORE);SetForegroundWindow(w);}CoUninitialize();return 0;}
    const bool captureMode=std::wstring(command).find(L"--capture")!=std::wstring::npos;
    WNDCLASSEXW wc{sizeof wc};wc.lpfnWndProc=wndproc;wc.hInstance=instance;wc.hCursor=LoadCursor(nullptr,IDC_ARROW);wc.lpszClassName=L"LampiaoMain";RegisterClassExW(&wc);wc.lpszClassName=L"LampiaoOverlay";RegisterClassExW(&wc);
    RECT rect{0,0,1180,790};AdjustWindowRect(&rect,WS_OVERLAPPEDWINDOW,FALSE);
    mainWindow=CreateWindowExW(0,L"LampiaoMain",L"lampião menu",WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,rect.right-rect.left,rect.bottom-rect.top,nullptr,nullptr,instance,nullptr);
    overlayWindow=CreateWindowExW(WS_EX_TOPMOST|WS_EX_TRANSPARENT|WS_EX_LAYERED|WS_EX_NOACTIVATE|WS_EX_TOOLWINDOW,L"LampiaoOverlay",L"lampião menu Overlay",WS_POPUP,0,0,1280,720,nullptr,nullptr,instance,nullptr);
    if(!mainWindow||!overlayWindow){MessageBoxW(nullptr,L"Falha ao criar janela",L"lampião menu",MB_ICONERROR);CoUninitialize();return 1;}
    SetLayeredWindowAttributes(overlayWindow,RGB(0,0,0),255,LWA_COLORKEY);MARGINS margins{-1,-1,-1,-1};DwmExtendFrameIntoClientArea(overlayWindow,&margins);BOOL dark=TRUE;DwmSetWindowAttribute(mainWindow,20,&dark,sizeof dark);
    D3D_FEATURE_LEVEL feature{};HRESULT hr=D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&device,&feature,&context);
    if(FAILED(hr))hr=D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_WARP,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&device,&feature,&context);
    if(FAILED(hr)||!panel.init(mainWindow,1180,790)||!overlay.init(overlayWindow,1280,720)){MessageBoxW(mainWindow,L"Falha ao iniciar DirectX 11",L"lampião menu",MB_ICONERROR);panel.destroy();overlay.destroy();if(context)context->Release();if(device)device->Release();CoUninitialize();return 2;}
    refreshBanner();loadPreviewAgent();
    ImGui::SetCurrentContext(panel.gui);theme();Settings settings;settings.load(root()/L"config.ini");settings.enabled=false;settings.aimEnabled=false;settings.recoilEnabled=false;
    Reader reader;AimController aimController;KeyBindingCapture binding;games::Preference preference=games::Preference::Automatic;games::Detection detected{};auto nextDetect=std::chrono::steady_clock::time_point{};bool visible=true;int tab=0,frames=0;std::string toast;auto lastSave=std::chrono::steady_clock::now();
    const int shortcutKeys[]={VK_INSERT,VK_F6,VK_END};
    std::array<bool,3> shortcutRegistered{};
    for(int i=0;i<3;++i)shortcutRegistered[i]=RegisterHotKey(mainWindow,i+1,MOD_NOREPEAT,shortcutKeys[i])!=0;
    ShowWindow(mainWindow,SW_SHOWDEFAULT);UpdateWindow(mainWindow);
    while(running){auto start=std::chrono::steady_clock::now();MSG msg{};
        if(start>=nextDetect){detected=games::detect();nextDetect=start+std::chrono::seconds(2);}
        auto currentGame=games::active(preference,detected);
        Snapshot snap=currentGame==games::Game::CS2?reader.snapshot():Snapshot{};
        DWORD foregroundPid{};GetWindowThreadProcessId(GetForegroundWindow(),&foregroundPid);
        bool gameFocused=snap.pid && foregroundPid==snap.pid;
        for(int i=0;i<3;++i){
            bool wanted=shortcutAvailable(binding.active,gameFocused,settings.aimEnabled,settings.aimVk,shortcutKeys[i]);
            if(wanted && !shortcutRegistered[i])shortcutRegistered[i]=RegisterHotKey(mainWindow,i+1,MOD_NOREPEAT,shortcutKeys[i])!=0;
            else if(!wanted && shortcutRegistered[i]){UnregisterHotKey(mainWindow,i+1);shortcutRegistered[i]=false;}
        }
        while(PeekMessageW(&msg,nullptr,0,0,PM_REMOVE)){
            if(msg.message==WM_QUIT)running=false;
            if(msg.message==WM_HOTKEY && msg.wParam>=1 && msg.wParam<=3){
                int i=static_cast<int>(msg.wParam)-1;
                bool allowed=shortcutAvailable(binding.active,gameFocused,settings.aimEnabled,settings.aimVk,shortcutKeys[i]);
                if(allowed){if(i==0){visible=!visible;ShowWindow(mainWindow,visible?SW_SHOW:SW_HIDE);if(visible)SetForegroundWindow(mainWindow);}if(i==1 && currentGame==games::Game::CS2)settings.enabled=!settings.enabled;if(i==2)running=false;}
            }
            TranslateMessage(&msg);DispatchMessageW(&msg);
        }if(!running)break;
        if(visible&&!IsIconic(mainWindow)){RECT r{};GetClientRect(mainWindow,&r);if(!panel.resize(r.right,r.bottom)){running=false;break;}panel.begin();
            if(currentGame==games::Game::Reforger)reforgerUi(preference,detected);
            else ui(settings,snap,tab,toast,aimController,binding,preference,detected);
            panel.render(true);
            // A newly selected game must gate input and overlay in this same frame.
            currentGame=games::active(preference,detected);
            if(currentGame==games::Game::Reforger)binding.cancel();
            if(captureMode&&++frames==10){fs::path out=root()/L"preview.bmp";capture(panel,out);running=false;}
            if(FAILED(panel.swap->Present(0,0))){running=false;break;}
        }
        RECT game{};HWND gameWindow{};HWND fg=GetForegroundWindow();
        int selectedVk=settings.aimVk;
        if(binding.poll(visible && fg==mainWindow,GetAsyncKeyState,selectedVk)){
            settings.aimVk=selectedVk;settings.aimKey=vkToLegacyAimKey(selectedVk);toast="Tecla: "+keyName(selectedVk);
        }
        bool haveGame=currentGame==games::Game::CS2 && gameRect(snap.pid,game,gameWindow);
        aimController.update(snap,settings,haveGame&&fg==gameWindow,game);
        bool show=currentGame==games::Game::CS2&&snap.ready&&haveGame&&(settings.enabled||settings.showFov||settings.referenceCrosshair)&&(fg==gameWindow||fg==mainWindow);
        if(show){int w=game.right-game.left,h=game.bottom-game.top;SetWindowPos(overlayWindow,HWND_TOPMOST,game.left,game.top,w,h,SWP_NOACTIVATE|SWP_SHOWWINDOW);
            if(visible&&fg==mainWindow)SetWindowPos(mainWindow,HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);
            if(!overlay.resize(w,h)){running=false;break;}overlay.begin();auto*d=ImGui::GetBackgroundDrawList();if(settings.showFov)d->AddCircle({w*.5f,h*.5f},settings.aimRadius,IM_COL32(245,245,245,200),96,1.5f);
            if(settings.referenceCrosshair)drawReferenceCrosshair(d,settings,{(float)w,(float)h});
            if(settings.enabled && settings.radarEnabled){float size=std::min({settings.radarSize,float(w)-28.f,float(h)-70.f});if(size>=80.f)drawRadar(d,snap,settings,{14.f,56.f},size,std::chrono::steady_clock::now());}
            for(const auto&p:snap.players){
                Actor a;if(screenActor(p,snap,(float)w,(float)h,a))actor(d,p,a,settings,{(float)w,(float)h});
                if(settings.enabled&&settings.offscreenArrows&&settings.enemies&&!p.ally&&std::isfinite(p.meters)&&p.meters>=0&&p.meters<=settings.maxDistance&&radar::available(snap,std::chrono::steady_clock::now())){
                    indicator::Arrow arrow;if(indicator::offscreen(p.head,snap.matrix,(float)w,(float)h,arrow))drawIndicator(d,arrow,{0,0},color(settings.enemy));
                }
            }
            if(settings.watermark){d->AddRectFilled({14,14},{310,44},IM_COL32(16,12,19,220),5);d->AddRectFilled({14,14},{17,44},IM_COL32(240,40,60,255),2);label(d,{27,20},snap.insecure?"LAMPIÃO MENU / TREINAMENTO -insecure":"LAMPIÃO MENU / EXTERNAL",IM_COL32(245,136,148,255),13,false);}overlay.render(false);if(FAILED(overlay.swap->Present(0,0))){running=false;break;}
        }else ShowWindow(overlayWindow,SW_HIDE);
        if(fg!=mainWindow)SetWindowPos(mainWindow,HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);
        if(start-lastSave>std::chrono::seconds(3)){try{settings.save(root()/L"config.ini");}catch(const std::exception&e){toast=e.what();}lastSave=start;}
        auto budget=std::chrono::duration<double>(1.0/settings.fps);auto elapsed=std::chrono::steady_clock::now()-start;if(elapsed<budget)std::this_thread::sleep_for(budget-elapsed);
    }
    try{settings.save(root()/L"config.ini");}catch(...){}
    for(int i=1;i<=3;++i)UnregisterHotKey(mainWindow,i);banner.release();previewAgent.release();overlay.destroy();panel.destroy();context->Release();device->Release();DestroyWindow(overlayWindow);DestroyWindow(mainWindow);CoUninitialize();return 0;
}
