#pragma once
#include "core.hpp"

namespace crimson::preview {
// Keep the current player while available; otherwise use the nearest valid pose.
inline const Player* select(const Snapshot& snap,int source,uint64_t& selectedPawn){
    if(!snap.ready){selectedPawn=0;return nullptr;}
    if(source==2){
        selectedPawn=0;
        return snap.localPlayer && snap.localPlayer->hasBones ? &*snap.localPlayer : nullptr;
    }
    bool ally=source==1;
    const Player* nearest=nullptr;
    for(const auto& player:snap.players){
        if(player.ally!=ally||!player.hasBones)continue;
        if(selectedPawn && player.pawn==selectedPawn)return &player;
        if(!nearest||player.meters<nearest->meters)nearest=&player;
    }
    selectedPawn=nearest?nearest->pawn:0;
    return nearest;
}
// Explain why the selected source cannot provide a pose yet.
enum class Status { disconnected, notReady, stale, noLocalPlayer, noPlayer, noBones, poseReady };
struct Result {const Player* player{};Status status{};};
inline Result inspect(const Snapshot& snap,int source,uint64_t& selectedPawn,std::chrono::steady_clock::time_point now){
    if(!snap.connected){selectedPawn=0;return {nullptr,Status::disconnected};}
    if(!snap.ready){selectedPawn=0;return {nullptr,Status::notReady};}
    if(snap.sampled.time_since_epoch().count()==0 || now-snap.sampled>=std::chrono::milliseconds(500)){
        selectedPawn=0;return {nullptr,Status::stale};
    }
    if(auto p=select(snap,source,selectedPawn))return {p,Status::poseReady};
    if(source==2){return {nullptr,snap.localPlayer?Status::noBones:Status::noLocalPlayer};}
    for(const auto& p:snap.players)if(p.ally==(source==1))return {nullptr,Status::noBones};
    return {nullptr,Status::noPlayer};
}
inline const char* message(Status status){
    switch(status){
        case Status::disconnected:return "CS2 desconectado";
        case Status::notReady:return "Leitura ainda indisponível";
        case Status::stale:return "Leitura atrasada";
        case Status::noLocalPlayer:return "Jogador local indisponível";
        case Status::noPlayer:return "Nenhum jogador da seleção";
        case Status::noBones:return "Ossos não disponíveis";
        case Status::poseReady:return "Pose disponível";
    }
    return "Aguardando dados";
}
}
