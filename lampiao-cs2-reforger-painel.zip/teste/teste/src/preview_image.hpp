#pragma once
#include <algorithm>
#include <array>
#include <cmath>

// Layout coordinates are calibrated to the bundled 395 x 700 Ava image.
namespace crimson::preview_image {
struct Point {float x{},y{};};
struct Layout {Point imageTop{},imageBottom{},top{},feet{},head{};std::array<Point,28> bones{};};
inline bool layout(float width,float height,Layout& result){
    if(!std::isfinite(width)||!std::isfinite(height)||width<100||height<160)return false;
    const float scale=std::min((width-55.f)/395.f,(height-85.f)/700.f);
    if(!std::isfinite(scale)||scale<=0)return false;
    Layout r;float x=(width-395.f*scale)*.5f,y=(height-700.f*scale)*.5f+2.f;
    auto point=[&](float px,float py){return Point{x+px*scale,y+py*scale};};
    r.imageTop=point(0,0);r.imageBottom=point(395,700);
    r.top=point(199,58);r.feet=point(199,686);r.head=point(184,112);
    r.bones[0]=point(195,370);r.bones[2]=point(191,298);r.bones[4]=point(190,222);
    r.bones[5]=point(184,158);r.bones[6]=r.head;
    r.bones[8]=point(128,181);r.bones[9]=point(101,256);r.bones[10]=point(109,145);
    r.bones[13]=point(247,183);r.bones[14]=point(272,268);r.bones[15]=point(296,369);
    r.bones[22]=point(157,377);r.bones[23]=point(161,505);r.bones[24]=point(160,663);
    r.bones[25]=point(224,377);r.bones[26]=point(269,498);r.bones[27]=point(289,661);
    result=r;return true;
}
}
