#pragma once
#include <algorithm>
#include <cmath>
#include <initializer_list>

namespace crimson::indicator {
struct Point {float x{},y{};};
struct Arrow {Point tip{},left{},right{};};
// Arrow for a projected point outside the viewport and in front of the camera.
// Points behind the camera are rejected because their screen direction is ambiguous.
template<class Position,class Matrix>
inline bool offscreen(const Position& p,const Matrix& m,float width,float height,Arrow& out){
    if(!std::isfinite(width)||!std::isfinite(height)||width<80||height<80 || !std::isfinite(p.x)||!std::isfinite(p.y)||!std::isfinite(p.z) || std::abs(p.x)>100000||std::abs(p.y)>100000||std::abs(p.z)>100000)return false;
    for(int i:{0,1,2,3,4,5,6,7,12,13,14,15})if(!std::isfinite(m[i]))return false;
    const double z=double(m[12])*p.x+double(m[13])*p.y+double(m[14])*p.z+m[15];
    if(!std::isfinite(z)||z<.01)return false;
    const double x=(double(m[0])*p.x+double(m[1])*p.y+double(m[2])*p.z+m[3])/z;
    const double y=(double(m[4])*p.x+double(m[5])*p.y+double(m[6])*p.z+m[7])/z;
    if(!std::isfinite(x)||!std::isfinite(y)||(x>=-1&&x<=1&&y>=-1&&y<=1))return false;
    const double dx=x*width*.5,dy=-y*height*.5,len=std::hypot(dx,dy);
    if(!std::isfinite(len)||len<.01)return false;
    const double ux=dx/len,uy=dy/len;
    const double tx=std::abs(ux)>.000001?(width*.5-22)/std::abs(ux):1e30;
    const double ty=std::abs(uy)>.000001?(height*.5-22)/std::abs(uy):1e30;
    const double t=std::min(tx,ty),px=width*.5+ux*t,py=height*.5+uy*t;
    Arrow result;
    result.tip={float(px),float(py)};
    result.left={float(px-ux*13-uy*6),float(py-uy*13+ux*6)};
    result.right={float(px-ux*13+uy*6),float(py-uy*13-ux*6)};
    out=result;return true;
}
}
