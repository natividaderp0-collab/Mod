#pragma once
#include <chrono>
#include <cmath>
#include <optional>
#include <vector>

namespace crimson::radar {
struct Point {float x{},y{};};
struct Marker {Point position;bool ally;};
// Coordinates use the map's fixed X/Y axes; they do not rotate with the camera.
template<class Position>
inline std::optional<Point> project(const Position& local,const Position& target,float rangeMeters,float radius){
    if(!std::isfinite(local.x)||!std::isfinite(local.y)||!std::isfinite(target.x)||!std::isfinite(target.y)||!std::isfinite(rangeMeters)||!std::isfinite(radius)||rangeMeters<=0||radius<=0)return {};
    const float x=(target.x-local.x)*.0254f,y=(target.y-local.y)*.0254f;
    if(!std::isfinite(x)||!std::isfinite(y)||std::hypot(x,y)>rangeMeters)return {};
    return Point{x*radius/rangeMeters,-y*radius/rangeMeters};
}
template<class Snapshot>
inline bool available(const Snapshot& s,std::chrono::steady_clock::time_point now){
    return s.ready && s.localAlive && s.localPlayer && s.sampled.time_since_epoch().count()!=0 && now>=s.sampled && now-s.sampled<std::chrono::milliseconds(500);
}
template<class Snapshot>
inline std::vector<Marker> markers(const Snapshot& s,float rangeMeters,float radius,bool enemies,bool allies,std::chrono::steady_clock::time_point now){
    std::vector<Marker> result;
    if(!available(s,now))return result;
    for(const auto& p:s.players){
        if((p.ally&&!allies)||(!p.ally&&!enemies))continue;
        auto point=project(s.localPlayer->origin,p.origin,rangeMeters,radius);
        if(point)result.push_back({*point,p.ally});
    }
    return result;
}
}
