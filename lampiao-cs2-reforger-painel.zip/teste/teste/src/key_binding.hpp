#pragma once
#include "core.hpp"
#include <cstdio>

namespace crimson {
inline int legacyAimKeyToVk(int key) {
    return key==1?VK_LBUTTON:key==2?VK_MENU:VK_RBUTTON;
}
inline int vkToLegacyAimKey(int vk) {
    return vk==VK_LBUTTON?1:(vk==VK_MENU||vk==VK_LMENU||vk==VK_RMENU)?2:0;
}
inline std::string keyName(int vk) {
    switch(vk){
        case VK_LBUTTON:return "Mouse esquerdo";
        case VK_RBUTTON:return "Mouse direito";
        case VK_MBUTTON:return "Mouse central";
        case VK_XBUTTON1:return "Mouse lateral 1";
        case VK_XBUTTON2:return "Mouse lateral 2";
        case VK_SHIFT:return "Shift";
        case VK_CONTROL:return "Ctrl";
        case VK_MENU:return "Alt";
    }
    UINT scancode=MapVirtualKeyW(static_cast<UINT>(vk),MAPVK_VK_TO_VSC_EX);
    LONG bits=static_cast<LONG>((scancode&0xffu)<<16);
    if((scancode&0xff00u)==0xe000u)bits|=1<<24;
    wchar_t name[128]{};
    if(scancode && GetKeyNameTextW(bits,name,128)>0)return utf8(name);
    char fallback[24];std::snprintf(fallback,sizeof fallback,"Tecla 0x%02X",vk);return fallback;
}
inline bool shortcutAvailable(bool capturing,bool gameFocused,bool aimEnabled,int aimVk,int shortcutVk) {
    return !capturing && !(gameFocused && aimEnabled && aimVk==shortcutVk);
}
class KeyBindingCapture {
public:
    using KeyReader=SHORT (WINAPI *)(int);
    bool active{},waitRelease{},ignoreLeft{};
    void begin(){active=true;waitRelease=true;ignoreLeft=false;}
    void cancel(){active=false;waitRelease=false;ignoreLeft=false;}
    bool poll(bool foreground,KeyReader readKey,int& value){
        if(!active)return false;
        if(!foreground){waitRelease=true;return false;}
        auto down=[&](int vk){return (readKey(vk)&0x8000)!=0;};
        if(waitRelease){
            for(int key=1;key<=254;++key)if(down(key))return false;
            waitRelease=false;return false;
        }
        // Prefer left/right modifiers over their generic virtual-key aliases.
        for(int key:{VK_LSHIFT,VK_RSHIFT,VK_LCONTROL,VK_RCONTROL,VK_LMENU,VK_RMENU}){
            if(down(key)){value=key;cancel();return true;}
        }
        for(int key=1;key<=254;++key){
            if(key==VK_LSHIFT||key==VK_RSHIFT||key==VK_LCONTROL||key==VK_RCONTROL||key==VK_LMENU||key==VK_RMENU)continue;
            if(key==VK_LBUTTON && ignoreLeft)continue;
            if(down(key)){value=key;cancel();return true;}
        }
        return false;
    }
};
}
