#pragma once
#include "core.hpp"
#include "aim_math.hpp"

namespace crimson {
// Input is only sent for a fresh snapshot while the game is in the foreground.
class AimController {
    using KeyReader=SHORT (WINAPI *)(int);
    using Sender=UINT (WINAPI *)(UINT,LPINPUT,int);
    using Clock=std::chrono::steady_clock;
    using Now=Clock::time_point (*)();
    KeyReader readKey; Sender sendInput; Now readNow;
    std::chrono::steady_clock::time_point seen{};
    uint64_t previousPawn{}, lockedTarget{}; bool havePunch{}; aim::Point previousPunch{}, remainder{};
    aim::AxisDamping horizontal, vertical;
    void resetAim() {lockedTarget=0;horizontal.reset();vertical.reset();}
    std::string lastAttempt="Nenhuma tentativa registrada.";
public:
    explicit AimController(KeyReader keyReader=GetAsyncKeyState, Sender sender=SendInput, Now nowReader=Clock::now):readKey(keyReader),sendInput(sender),readNow(nowReader){}
    const std::string& status() const {return lastAttempt;}
    void reset(){havePunch=false;previousPawn=0;remainder={};resetAim();}
    void update(const Snapshot& snap,const Settings& settings,bool foreground,const RECT& rect) {
        const auto now=readNow();
        const bool aimKey=settings.aimEnabled && (readKey(settings.aimVk)&0x8000);
        if(!foreground){reset();return;}
        if(!snap.ready || !snap.localAlive || snap.sampled.time_since_epoch().count()==0 || now-snap.sampled>std::chrono::milliseconds(100)) {
            if(aimKey)lastAttempt=!snap.ready?"Leitura do jogo indisponível.":(!snap.localAlive?"Jogador local indisponível ou morto.":"Leitura atrasada.");
            reset();return;
        }
        if(snap.sampled==seen)return;
        seen=snap.sampled;
        if(previousPawn!=snap.localPawn){reset();previousPawn=snap.localPawn;}
        const bool recoilHeld=settings.recoilEnabled && (readKey(VK_LBUTTON)&0x8000) && snap.recoilReady;
        const bool recoilKey=recoilHeld && snap.shots>=2;
        if(!aimKey && !recoilHeld){reset();return;}
        if(!aimKey || !settings.aimStabilize)resetAim();
        aim::Point move{};
        bool targetFound=false,inDeadzone=false;
        const float w=float(rect.right-rect.left),h=float(rect.bottom-rect.top);
        if(aimKey && settings.aimPriority==1 && !snap.localPlayer){resetAim();lastAttempt="Posição local indisponível.";}
        else if(aimKey && w>0 && h>0){
            float best=settings.aimRadius*settings.aimRadius; aim::Point target{}; bool found=false,foundLocked=false;uint64_t targetPawn{};
            for(const auto& player:snap.players){
                if(player.ally)continue;
                Vec3 point=aim::targetPosition(player.head,player.bones,player.hasBones,settings.aimTarget);
                Vec2 projected{}; if(!project(point,snap.matrix,w,h,projected))continue;
                aim::Point pos{projected.x,projected.y}; if(!aim::inRadius(pos,w,h,settings.aimRadius))continue;
                float dx=pos.x-w*.5f,dy=pos.y-h*.5f,dist=dx*dx+dy*dy;
                if(settings.aimPriority==1 && (!std::isfinite(player.meters)||player.meters<0))continue;
                float rank=settings.aimPriority==1?player.meters:dist;
                bool same=settings.aimStabilize && lockedTarget && player.pawn==lockedTarget;
                if(same || (!foundLocked && (!found || rank<best))){best=rank;target=pos;targetPawn=player.pawn;found=true;foundLocked=same;}
            }
            targetFound=found;
            if(!found){resetAim();lastAttempt="Nenhum inimigo válido dentro do FOV.";}
            if(found){
                if(settings.aimStabilize && targetPawn!=lockedTarget){resetAim();lockedTarget=targetPawn;}
                auto& m=snap.matrix;
                float denom=std::sqrt(m[12]*m[12]+m[13]*m[13]+m[14]*m[14]);
                if(std::isfinite(denom) && denom>0.01f){float fx=std::sqrt(m[0]*m[0]+m[1]*m[1]+m[2]*m[2])/denom;float fy=std::sqrt(m[4]*m[4]+m[5]*m[5]+m[6]*m[6])/denom;
                    if(std::isfinite(fx) && std::isfinite(fy) && fx>0.01f && fy>0.01f) {
                        move=aim::mouseMove(target,w,h,fx,fy,settings.aimSensitivity,settings.aimSmooth,settings.aimGain);
                        if(settings.aimStabilize){
                            float dx=target.x-w*.5f,dy=target.y-h*.5f;
                            float sx=horizontal.update(dx,settings.aimDeadzone),sy=vertical.update(dy,settings.aimDeadzone);
                            move.x*=sx;move.y*=sy;inDeadzone=sx==0 && sy==0;
                            if(!recoilKey && sx==0)remainder.x=0;
                            if(!recoilKey && sy==0)remainder.y=0;
                        }
                    }else {targetFound=false;lastAttempt="Matriz de visão inválida.";}}
                else {targetFound=false;lastAttempt="Matriz de visão inválida.";}
            }
        }
        if(recoilHeld){
            aim::Point current{snap.punch.x,snap.punch.y};
            if(recoilKey && havePunch){auto correction=aim::recoilMove(previousPunch,current,settings.aimSensitivity,settings.recoilStrength);move.x+=correction.x;move.y+=correction.y;}
            previousPunch=current;havePunch=true;
        }else havePunch=false;
        remainder.x+=move.x; remainder.y+=move.y;
        LONG dx=static_cast<LONG>(std::clamp(remainder.x,-2048.f,2048.f)); LONG dy=static_cast<LONG>(std::clamp(remainder.y,-2048.f,2048.f));
        // Do not accumulate large queued movements across frames.
        remainder.x=std::clamp(remainder.x-dx,-1.f,1.f);remainder.y=std::clamp(remainder.y-dy,-1.f,1.f);
        if(dx||dy){
            INPUT input{};input.type=INPUT_MOUSE;input.mi.dx=dx;input.mi.dy=dy;input.mi.dwFlags=MOUSEEVENTF_MOVE;
            bool sent=sendInput(1,&input,sizeof input)==1;
            if(aimKey && targetFound)lastAttempt=sent?"Movimento enviado ao Windows (confirme no jogo).":"Windows recusou o movimento; confira as permissões.";
            if(!sent)remainder={};
        }else if(aimKey && targetFound)lastAttempt=inDeadzone?"Alvo na zona de estabilização.":"Alvo encontrado; correção abaixo de um passo do mouse.";
    }
};
}
