#pragma once
#include "preview_pose.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <vector>
#include <utility>

// A small independent 3D model, projected into the ImGui preview. It does not
// load or identify any of the game's models or textures.
namespace crimson::preview3d {
struct Vec {float x{},y{},z{};};
inline Vec operator+(Vec a,Vec b){return {a.x+b.x,a.y+b.y,a.z+b.z};}
inline Vec operator-(Vec a,Vec b){return {a.x-b.x,a.y-b.y,a.z-b.z};}
inline Vec operator*(Vec a,float n){return {a.x*n,a.y*n,a.z*n};}
inline float dot(Vec a,Vec b){return a.x*b.x+a.y*b.y+a.z*b.z;}
inline Vec cross(Vec a,Vec b){return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
inline Vec unit(Vec a){float n=std::sqrt(dot(a,a));return n>0.001f?a*(1.f/n):Vec{};}
struct Material {float r,g,b;};
struct Face {std::array<Vec,4> points;Material material;float light;};
struct ProjectedFace {std::array<preview::Point,4> points;float depth{};Material material;float light{};};
struct Scene {std::vector<ProjectedFace> faces;std::array<preview::Point,28> joints{};float top{},bottom{};};
using Joints=std::array<Vec,28>;
constexpr std::array<int,17> used={0,2,4,5,6,8,9,10,13,14,15,22,23,24,25,26,27};
inline Joints example(){
    Joints b{};b[0]={0,0,35};b[2]={0,0,45};b[4]={0,0,55};b[5]={0,0,65};b[6]={0,0,72};
    b[8]={-10,0,56};b[9]={-17,1,45};b[10]={-19,2,34};b[13]={10,0,56};b[14]={17,1,45};b[15]={19,2,34};
    b[22]={-5,0,30};b[23]={-6,0,15};b[24]={-7,1,0};b[25]={5,0,30};b[26]={6,0,15};b[27]={7,1,0};return b;
}
// Align the shoulders with the viewer while retaining forward/back movement.
template<class Bones> inline bool orient(const Bones& b,Joints& out){
    preview::Pose validate;if(!preview::layout(b,300,450,validate))return false;
    const auto& root=b[0];float x=b[13].x-b[8].x,y=b[13].y-b[8].y;
    float len=std::hypot(x,y);if(len<.01f){x=1;y=0;}else{x/=len;y/=len;}
    Joints result{};
    for(int i:used){float dx=b[i].x-root.x,dy=b[i].y-root.y;result[i]={dx*x+dy*y,-dx*y+dy*x,b[i].z-root.z};}
    out=result;return true;
}
inline void prism(std::vector<Face>& faces,Vec from,Vec to,float width,float depth,Material material){
    Vec axis=unit(to-from);if(dot(axis,axis)<.5f)return;
    Vec reference=std::abs(axis.y)>.92f?Vec{1,0,0}:Vec{0,1,0};
    Vec x=unit(cross(reference,axis))*(width*.5f),y=unit(cross(axis,x))*(depth*.5f);
    // An octagonal cross-section gives each piece beveled, shaded edges.
    constexpr std::array<std::array<float,2>,8> ring={{{{-.6f,-1}},{{.6f,-1}},{{1,-.6f}},{{1,.6f}},{{.6f,1}},{{-.6f,1}},{{-1,.6f}},{{-1,-.6f}}}};
    std::array<Vec,8> lo{},hi{};
    for(int i=0;i<8;++i){Vec offset=x*ring[i][0]+y*ring[i][1];lo[i]=from+offset;hi[i]=to+offset;}
    const Vec lamp=unit(Vec{-1,-2,3});
    auto add=[&](Vec a,Vec b,Vec c,Vec d){
        Face face{{a,b,c,d},material,0};
        Vec normal=unit(cross(b-a,c-a));
        face.light=.55f+.45f*std::max(0.f,dot(normal,lamp));faces.push_back(face);
    };
    for(int i=0;i<8;++i){int k=(i+1)%8;add(lo[i],lo[k],hi[k],hi[i]);}
    for(int i=1;i<7;i+=2){add(hi[0],hi[i],hi[i+1],hi[i+2]);add(lo[i+2],lo[i+1],lo[i],lo[0]);}
}
inline std::vector<Face> model(const Joints& j){
    std::vector<Face> faces;faces.reserve(420);
    constexpr Material suit{.19f,.25f,.29f},pants{.19f,.22f,.25f},armor{.34f,.37f,.34f};
    constexpr Material dark{.10f,.13f,.16f},skin{.63f,.49f,.39f},accent{.66f,.26f,.22f};
    prism(faces,j[0]+Vec{0,0,-3},j[4]+Vec{0,0,3},21,13,suit);
    prism(faces,j[2]+Vec{0,-6,-2},j[4]+Vec{0,-6,2},19,4,armor);
    prism(faces,j[0]+Vec{0,0,-5},j[0]+Vec{0,0,2},20,14,dark);
    prism(faces,j[4]+Vec{0,0,1},j[5]+Vec{0,0,2},7,8,suit);
    prism(faces,j[5]+Vec{0,0,-1},j[6]+Vec{0,0,4},8,8,skin);
    prism(faces,j[6]+Vec{0,0,-1},j[6]+Vec{0,0,9},13,12,skin);
    prism(faces,j[6]+Vec{0,0,5},j[6]+Vec{0,0,12},15,14,dark);
    prism(faces,j[6]+Vec{0,-7,3},j[6]+Vec{0,-7,7},12,2,dark);
    prism(faces,j[6]+Vec{0,-7,-1},j[6]+Vec{0,-7,2},9,2,dark);
    for(auto side:std::array<std::array<int,6>,2>{{{{8,9,10,22,23,24}},{{13,14,15,25,26,27}}}}){
        prism(faces,j[side[0]],j[side[1]],8,9,suit);
        prism(faces,j[side[1]],j[side[2]],7,8,suit);
        prism(faces,j[side[2]]+Vec{0,0,-2},j[side[2]]+Vec{0,0,3},7,8,dark);
        prism(faces,j[side[3]],j[side[4]],10,11,pants);
        prism(faces,j[side[4]],j[side[5]],8,9,pants);
        prism(faces,j[side[5]]+Vec{0,-3,-2},j[side[5]]+Vec{0,-3,4},9,15,dark);
    }
    // Vest details give the generic figure a tactical appearance.
    prism(faces,j[2]+Vec{-5,-9,0},j[2]+Vec{-5,-9,6},5,2,dark);
    prism(faces,j[2]+Vec{5,-9,0},j[2]+Vec{5,-9,6},5,2,dark);
    prism(faces,j[4]+Vec{0,-9,-3},j[4]+Vec{0,-9,-1},8,2,accent);
    return faces;
}
inline bool project(const Joints& j,float width,float height,Scene& out){
    if(!std::isfinite(width)||!std::isfinite(height)||width<100||height<160)return false;
    for(int i:used)if(!std::isfinite(j[i].x)||!std::isfinite(j[i].y)||!std::isfinite(j[i].z)||std::abs(j[i].x)>150||std::abs(j[i].y)>150||std::abs(j[i].z)>150)return false;
    auto faces=model(j);if(faces.empty())return false;
    constexpr float c=.94f,s=.342f;
    auto rotate=[](Vec p){return Vec{p.x*c+p.y*s,-p.x*s+p.y*c,p.z};};
    float minX=1e9f,maxX=-1e9f,minZ=1e9f,maxZ=-1e9f;
    for(const auto& face:faces)for(Vec p:face.points){p=rotate(p);minX=std::min(minX,p.x);maxX=std::max(maxX,p.x);minZ=std::min(minZ,p.z);maxZ=std::max(maxZ,p.z);}
    if(maxZ-minZ<15||maxZ-minZ>180||maxX-minX>240)return false;
    float scale=std::min((width-75.f)/std::max(60.f,maxX-minX+14.f),(height-105.f)/std::max(90.f,maxZ-minZ+14.f));
    if(!std::isfinite(scale)||scale<=0)return false;
    float midX=(minX+maxX)*.5f,base=(height+(maxZ-minZ+14)*scale)*.5f+5.f;
    auto toScreen=[&](Vec p){p=rotate(p);return preview::Point{width*.5f+(p.x-midX)*scale,base-(p.z-minZ+7)*scale};};
    Scene scene;scene.top=base-(maxZ-minZ+14)*scale;scene.bottom=base;scene.faces.reserve(faces.size());
    for(int i:used)scene.joints[i]=toScreen(j[i]);
    for(const auto& face:faces){ProjectedFace v{};v.material=face.material;v.light=face.light;
        for(int i=0;i<4;++i){v.points[i]=toScreen(face.points[i]);v.depth+=rotate(face.points[i]).y;}
        scene.faces.push_back(v);
    }
    std::stable_sort(scene.faces.begin(),scene.faces.end(),[](const auto& a,const auto& b){return a.depth>b.depth;});
    out=std::move(scene);return true;
}
}
