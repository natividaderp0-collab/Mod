# Build locally with MSYS2 UCRT64/MinGW or Visual Studio 2022/2026.
param([ValidateSet('Release','Debug')][string]$Configuration='Release')
$ErrorActionPreference='Stop'

# Prefer a complete x64 MSYS2 toolchain. A non-default MSYS2 directory works
# too when Compilar.bat is launched from its UCRT64/MinGW64 shell.
$bins=@('C:\msys64\ucrt64\bin','C:\msys64\mingw64\bin')
$gccCommand=Get-Command 'g++.exe' -ErrorAction SilentlyContinue
if($gccCommand){$bins+=Split-Path -Parent $gccCommand.Source}
$mode=$null
foreach($bin in $bins){
    $gcc=Join-Path $bin 'g++.exe'
    $candidateCmake=Join-Path $bin 'cmake.exe'
    $make=Join-Path $bin 'mingw32-make.exe'
    $candidateCtest=Join-Path $bin 'ctest.exe'
    if(!(Test-Path -LiteralPath $gcc) -or !(Test-Path -LiteralPath $candidateCmake) -or !(Test-Path -LiteralPath $make) -or !(Test-Path -LiteralPath $candidateCtest)){continue}
    $machine=@(& $gcc -dumpmachine)
    if($LASTEXITCODE -ne 0 -or !$machine -or $machine[0] -notmatch '^x86_64-.*mingw'){continue}
    $env:PATH=$bin+[IO.Path]::PathSeparator+$env:PATH
    $cmake=$candidateCmake;$ctest=$candidateCtest;$mode='mingw'
    $buildDir=Join-Path $PSScriptRoot ('build-mingw-'+$Configuration)
    $configure=@('-S',$PSScriptRoot,'-B',$buildDir,'-G','MinGW Makefiles',('-DCMAKE_MAKE_PROGRAM='+$make),('-DCMAKE_CXX_COMPILER='+$gcc),('-DCMAKE_BUILD_TYPE='+$Configuration))
    $exeDir=$buildDir
    Write-Host 'Compilador selecionado: MSYS2 MinGW x64'
    break
}

# Use Visual Studio when available, without requiring a specific edition.
if(!$mode){
    $programFiles86=${env:ProgramFiles(x86)}
    $vswhere=if($programFiles86){Join-Path $programFiles86 'Microsoft Visual Studio\Installer\vswhere.exe'}else{$null}
    if(!$vswhere -or !(Test-Path -LiteralPath $vswhere)){
        $found=Get-Command 'vswhere.exe' -ErrorAction SilentlyContinue
        if($found){$vswhere=$found.Source}else{$vswhere=$null}
    }
    if($vswhere){
        $versions=@(
            @{range='[17.0,18.0)';generator='Visual Studio 17 2022';folder='build-vs2022'},
            @{range='[18.0,19.0)';generator='Visual Studio 18 2026';folder='build-vs2026'}
        )
        foreach($version in $versions){
            $vsInstallations=@(& $vswhere -latest -prerelease -products '*' -version $version.range -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath)
            if($LASTEXITCODE -ne 0 -or $vsInstallations.Count -eq 0){continue}
            $vs=$vsInstallations[0]
            $candidateCmake=Join-Path $vs 'Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe'
            if(!(Test-Path -LiteralPath $candidateCmake)){
                $foundCmake=Get-Command 'cmake.exe' -ErrorAction SilentlyContinue
                if(!$foundCmake){continue}
                $candidateCmake=$foundCmake.Source
            }
            $candidateCtest=Join-Path (Split-Path -Parent $candidateCmake) 'ctest.exe'
            if(!(Test-Path -LiteralPath $candidateCtest)){continue}
            $cmake=$candidateCmake;$ctest=$candidateCtest;$mode='visualstudio'
            $buildDir=Join-Path $PSScriptRoot $version.folder
            $configure=@('-S',$PSScriptRoot,'-B',$buildDir,'-G',$version.generator,'-A','x64')
            $exeDir=Join-Path $buildDir $Configuration
            Write-Host ('Compilador selecionado: '+$version.generator)
            break
        }
    }
}
if(!$mode){
    throw 'Nenhum compilador x64 encontrado. Instale o MSYS2 UCRT64 com gcc, cmake e make (veja LEIA-ME-ALTERACOES.txt), ou Visual Studio 2022/2026 com Desenvolvimento para desktop com C++.'
}
& $cmake @configure
if($LASTEXITCODE){throw 'Falha ao configurar CMake. Confira a versao do CMake e as ferramentas C++.'}
& $cmake --build $buildDir --config $Configuration --parallel 2
if($LASTEXITCODE){throw 'Falha ao compilar'}
& $ctest --test-dir $buildDir -C $Configuration --output-on-failure
if($LASTEXITCODE){throw 'Falha na validacao'}
$dest=Join-Path $PSScriptRoot 'dist'
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Copy-Item -LiteralPath (Join-Path $exeDir 'CrimsonESP.exe') -Destination $dest -Force
Copy-Item -LiteralPath (Join-Path $exeDir 'offset_probe.exe') -Destination $dest -Force
$previewImage=Join-Path $PSScriptRoot 'assets\preview_agent.png'
if(Test-Path -LiteralPath $previewImage){Copy-Item -LiteralPath $previewImage -Destination $dest -Force}
& (Join-Path $dest 'offset_probe.exe')
if($LASTEXITCODE){Write-Warning 'CS2 nao encontrado no momento; os offsets serao extraidos quando o jogo for aberto.'}
Write-Host "Pronto: $dest\CrimsonESP.exe"
