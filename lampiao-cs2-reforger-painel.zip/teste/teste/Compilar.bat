@echo off
rem Batch - Compilar.bat - lampião menu - Windows x64
cd /d "%~dp0"
echo Compilando lampião menu...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1"
if errorlevel 1 (
  echo.
  echo Erro na compilacao.
  pause
  exit /b 1
)
echo.
echo Compilacao concluida com sucesso!
pause
