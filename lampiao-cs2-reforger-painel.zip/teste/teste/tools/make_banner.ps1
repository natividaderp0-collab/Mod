Add-Type -AssemblyName System.Drawing
$w = 336
$h = 130
$bmp = [System.Drawing.Bitmap]::new($w, $h)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit

$c1 = [System.Drawing.Color]::FromArgb(40, 16, 24)
$c2 = [System.Drawing.Color]::FromArgb(18, 16, 22)
$rect = [System.Drawing.Rectangle]::new(0, 0, $w, $h)
$brush = [System.Drawing.Drawing2D.LinearGradientBrush]::new($rect, $c1, $c2, [System.Drawing.Drawing2D.LinearGradientMode]::ForwardDiagonal)
$g.FillRectangle($brush, $rect)

$pen = [System.Drawing.Pen]::new([System.Drawing.Color]::FromArgb(235, 38, 60), 3)
$g.DrawRectangle($pen, 1, 1, $w - 2, $h - 2)

$penInner = [System.Drawing.Pen]::new([System.Drawing.Color]::FromArgb(80, 240, 60, 80), 1)
$g.DrawRectangle($penInner, 4, 4, $w - 8, $h - 8)

$fontTitle = [System.Drawing.Font]::new('Segoe UI', 22.0, [System.Drawing.FontStyle]::Bold)
$brushWhite = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(245, 245, 250))
$brushRed = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(245, 45, 68))

$sf = [System.Drawing.StringFormat]::new()
$sf.Alignment = [System.Drawing.StringAlignment]::Center
$sf.LineAlignment = [System.Drawing.StringAlignment]::Center

$g.DrawString('LAMPIAO', $fontTitle, $brushRed, [float]($w / 2), [float]40.0, $sf)

$fontSub = [System.Drawing.Font]::new('Segoe UI', 11.0, [System.Drawing.FontStyle]::Bold)
$g.DrawString('MENU PREMIUM', $fontSub, $brushWhite, [float]($w / 2), [float]85.0, $sf)

$outPath = 'C:\Users\abraa\Downloads\teste\teste\dist\banner.png'
$bmp.Save($outPath, [System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose()
$bmp.Dispose()
Write-Host "Banner salvo com sucesso em: $outPath"
