// Exercise the same draw path used by the preview and the in-game overlay.
#define wWinMain lampiao_application_entry
#include "../src/main.cpp"
#undef wWinMain
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
#include <cmath>

int main(){
    ImGui::CreateContext();
    auto& io=ImGui::GetIO();io.DisplaySize={1200,800};io.DeltaTime=1.f/60.f;
    unsigned char* pixels{};int w{},h{};io.Fonts->GetTexDataAsRGBA32(&pixels,&w,&h);
    ImGui::NewFrame();ImGui::SetNextWindowPos({0,0});ImGui::SetNextWindowSize({1200,800});ImGui::Begin("validation");
    ImDrawList* draw=ImGui::GetWindowDrawList();
    Settings s;s.enabled=false;s.enemies=false;s.allies=false;s.maxDistance=5;
    s.box=false;s.skeleton=false;s.names=false;s.health=false;s.armor=false;s.distance=false;s.head=false;s.snaplines=false;s.fill=false;
    Player p;p.meters=100;p.health=84;p.armor=72;p.name="Jogador";
    Actor a;a.top={350,170};a.feet={350,450};a.head={350,190};
    a.valid[6]=a.valid[5]=true;a.b[6]={350,190};a.b[5]={350,215};
    auto count=[&]{return draw->VtxBuffer.Size;};
    int initial=count();actor(draw,p,a,s,{300,400},true,{200,100});assert(count()==initial);
    for(bool Settings::* flag:{&Settings::box,&Settings::skeleton,&Settings::names,&Settings::health,&Settings::armor,&Settings::distance,&Settings::head,&Settings::fill,&Settings::healthNumbers}){
        initial=count();s.*flag=true;actor(draw,p,a,s,{300,400},true,{200,100});assert(count()>initial);s.*flag=false;
    }
    s.snaplines=true;s.lineOrigin=0;initial=count();
    actor(draw,p,a,s,{300,400},true,{200,100});assert(count()>initial);
    bool foundStart=false;
    for(int i=initial;i<count();++i){const ImVec2 v=draw->VtxBuffer[i].pos;if(std::abs(v.x-350)<4 && std::abs(v.y-100)<4)foundStart=true;}
    assert(foundStart);
    // Preview filters do not weaken the game's enabled/team/range checks.
    s.box=true;s.snaplines=false;s.enabled=true;initial=count();
    actor(draw,p,a,s,{1200,800});assert(count()==initial);
    s.enemies=true;actor(draw,p,a,s,{1200,800});assert(count()==initial);
    p.meters=1;actor(draw,p,a,s,{1200,800});assert(count()>initial);
    s.enabled=false;initial=count();actor(draw,p,a,s,{1200,800});assert(count()==initial);
    indicator::Arrow arrow{{100,100},{85,94},{85,106}};initial=count();drawIndicator(draw,arrow,{0,0},IM_COL32_WHITE);assert(count()>initial);
    initial=count();s.crosshairStyle=0;drawReferenceCrosshair(draw,s,{1200,800});assert(count()>initial);
    initial=count();s.crosshairStyle=1;drawReferenceCrosshair(draw,s,{1200,800});assert(count()>initial);
    initial=count();s.crosshairStyle=0;s.crosshairSize=2;drawReferenceCrosshair(draw,s,{1200,800});assert(count()>initial);
    ImGui::End();ImGui::EndFrame();ImGui::DestroyContext();
}
