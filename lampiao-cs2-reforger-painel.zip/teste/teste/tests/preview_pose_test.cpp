#include "../src/preview_pose.hpp"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <array>
#include <cassert>
#include <cmath>
#include <limits>
using namespace crimson::preview;
struct Vec {float x{},y{},z{};};
int main(){
    std::array<Vec,28> b{};
    b[0]={0,0,35};b[2]={0,0,45};b[4]={0,0,55};b[5]={0,0,65};b[6]={0,0,72};
    b[8]={-10,0,56};b[9]={-18,0,45};b[10]={-20,0,35};
    b[13]={10,0,56};b[14]={18,0,45};b[15]={20,0,35};
    b[22]={-5,0,30};b[23]={-6,0,15};b[24]={-7,0,0};
    b[25]={5,0,30};b[26]={6,0,15};b[27]={7,0,0};
    Pose a;assert(layout(b,300,450,a));assert(a.top<a.bones[6].y && a.bones[6].y<a.bones[0].y && a.bones[0].y<a.bones[24].y);
    assert(a.bones[8].x<a.bones[13].x);
    auto translated=b;for(auto& v:translated){v.x+=1000;v.y-=200;v.z+=80;}
    Pose t;assert(layout(translated,300,450,t));assert(std::abs(a.bones[6].y-t.bones[6].y)<.001f && std::abs(a.bones[8].x-t.bones[8].x)<.001f);
    auto rotated=b;for(auto& v:rotated){float x=v.x;v.x=-v.y;v.y=x;}
    Pose r;assert(layout(rotated,300,450,r));assert(std::abs(a.bones[8].x-r.bones[8].x)<.001f);
    auto crouched=b;for(auto& v:crouched)if(v.z>35)v.z-=15;
    Pose c;assert(layout(crouched,300,450,c));assert(c.top>a.top);
    assert(!layout(b,50,100,a));
    b[6].z=std::numeric_limits<float>::quiet_NaN();assert(!layout(b,300,450,a));
}
