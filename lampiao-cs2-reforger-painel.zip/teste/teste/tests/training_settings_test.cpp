#include "../src/core.hpp"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
int main(){
    using namespace crimson;
    auto path=fs::temp_directory_path()/(L"lampiao_training_"+std::to_wstring(GetCurrentProcessId())+L".ini");
    Settings a;a.offscreenArrows=true;a.healthNumbers=true;a.aimPriority=1;a.radarEnabled=true;a.radarRange=42;a.radarSize=210;a.referenceCrosshair=true;a.crosshairStyle=1;a.crosshairSize=11;a.save(path);
    Settings b;assert(b.load(path));assert(b.offscreenArrows&&b.healthNumbers&&b.aimPriority==1&&b.radarEnabled&&b.radarRange==42&&b.radarSize==210&&b.referenceCrosshair&&b.crosshairStyle==1&&b.crosshairSize==11);
    {std::ofstream f(path);f<<"box=0\nenemies=1\n";}
    Settings legacy;assert(legacy.load(path));assert(!legacy.offscreenArrows&&!legacy.healthNumbers&&legacy.aimPriority==0&&!legacy.radarEnabled&&!legacy.referenceCrosshair&&legacy.radarRange==150&&legacy.radarSize==180&&legacy.crosshairStyle==0&&!legacy.box);
    {std::ofstream f(path);f<<"radarRange=1\nradarSize=999\ncrosshairSize=90\ncrosshairStyle=20\naimPriority=9\n";}
    assert(legacy.load(path));assert(legacy.radarRange==10&&legacy.radarSize==300&&legacy.crosshairSize==18&&legacy.crosshairStyle==1&&legacy.aimPriority==1);
    {std::ofstream f(path);f<<"radarRange=nan\n";}
    assert(!legacy.load(path)&&legacy.radarRange==10);fs::remove(path);
}
