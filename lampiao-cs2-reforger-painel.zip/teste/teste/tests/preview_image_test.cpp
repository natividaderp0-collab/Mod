#include "../src/preview_image.hpp"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
#include <cmath>
#include <limits>
using namespace crimson::preview_image;
int main(){
    Layout a;assert(layout(320,400,a));
    assert(a.imageTop.x>=0&&a.imageTop.y>=0&&a.imageBottom.x<=320&&a.imageBottom.y<=400);
    assert(a.top.y<a.head.y&&a.head.y<a.bones[4].y&&a.bones[4].y<a.bones[0].y&&a.bones[0].y<a.feet.y);
    assert(a.bones[8].x<a.bones[13].x&&a.bones[9].y>a.bones[10].y);
    Layout b;assert(layout(700,700,b));assert(b.top.y<b.feet.y);
    assert(!layout(50,100,b));assert(!layout(std::numeric_limits<float>::quiet_NaN(),400,b));
}
