#include "../src/aim_controller.hpp"
#include <cstdio>
#include <cstdlib>
// Keep checks active in Release and print the failure into CTest output.
#define CHECK(expr) do { if (!(expr)) { std::fprintf(stderr,"FAIL %s:%d: %s\n",__FILE__,__LINE__,#expr); std::exit(EXIT_FAILURE); } } while(false)
#include <chrono>
#include <limits>
#include <string>

using Clock=std::chrono::steady_clock;
static auto simulatedNow=Clock::time_point(std::chrono::seconds(10));
static Clock::time_point fakeNow() { return simulatedNow; }

static int heldKey = VK_RBUTTON, attempts = 0;
static LONG sentX = 0, sentY = 0;
static bool inputAccepted = true;
static SHORT WINAPI fakeKey(int key) { return key == heldKey ? static_cast<SHORT>(0x8000) : 0; }
static UINT WINAPI fakeSend(UINT n, LPINPUT input, int) {
    CHECK(n == 1 && input->type == INPUT_MOUSE);
    ++attempts; sentX = input->mi.dx; sentY = input->mi.dy; return inputAccepted ? 1 : 0;
}

int main() {
    using namespace crimson;
    Settings settings; settings.aimEnabled=true; settings.aimRadius=150; settings.aimSmooth=1;
    Snapshot snap; snap.ready=true; snap.localAlive=true; snap.localPawn=1;
    snap.matrix={1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,1,0};
    Player player; player.pawn=100; player.hasBones=true; player.bones[6]={1,0,10};player.bones[5]={.5f,0,10};player.bones[4]={-1,0,10};player.head=player.bones[6];
    snap.players.push_back(player);
    RECT rect{0,0,1920,1080};
    // Advance a logical frame rather than relying on Windows clock resolution.
    auto fresh=[&] {simulatedNow+=std::chrono::milliseconds(1);snap.sampled=simulatedNow;};
    auto target=[&](int part) {
        AimController controller(fakeKey,fakeSend,fakeNow); settings.aimTarget=part; attempts=0;sentX=0;fresh();
        controller.update(snap,settings,true,rect);CHECK(attempts==1);return sentX;
    };
    {
        // An already processed sample must never generate a second movement.
        AimController controller(fakeKey,fakeSend,fakeNow);attempts=0;fresh();
        controller.update(snap,settings,true,rect);CHECK(attempts==1);
        controller.update(snap,settings,true,rect);CHECK(attempts==1);
        fresh();controller.update(snap,settings,true,rect);CHECK(attempts==2);
    }
    {
        // Freshness boundaries use exactly the same deterministic clock.
        AimController controller(fakeKey,fakeSend,fakeNow);attempts=0;fresh();
        snap.sampled=simulatedNow-std::chrono::milliseconds(100);
        controller.update(snap,settings,true,rect);CHECK(attempts==1);
        fresh();snap.sampled=simulatedNow-std::chrono::milliseconds(101);
        controller.update(snap,settings,true,rect);CHECK(attempts==1);
        CHECK(controller.status().find("atrasada")!=std::string::npos);
        snap.sampled={};controller.update(snap,settings,true,rect);CHECK(attempts==1);
    }
    settings.aimGain=1;LONG normal=target(0);
    settings.aimGain=2;LONG boosted=target(0);
    CHECK(boosted>=normal*2-1 && boosted<=normal*2+1);
    LONG head=target(0),neck=target(1),chest=target(2);
    CHECK(head>neck && neck>0 && chest<0);
    {
        AimController controller(fakeKey,fakeSend,fakeNow);settings.aimTarget=0;settings.aimVk='K';
        attempts=0;fresh();controller.update(snap,settings,true,rect);CHECK(attempts==0);
        heldKey='K';fresh();controller.update(snap,settings,true,rect);CHECK(attempts==1);
        attempts=0;fresh();controller.update(snap,settings,false,rect);CHECK(attempts==0);
        heldKey=VK_RBUTTON;settings.aimVk=VK_RBUTTON;
    }
    {
        AimController controller(fakeKey,fakeSend,fakeNow);attempts=0;
        snap.sampled=simulatedNow-std::chrono::seconds(1);
        controller.update(snap,settings,true,rect);CHECK(attempts==0);
        CHECK(controller.status().find("atrasada")!=std::string::npos);
        fresh();snap.localAlive=false;controller.update(snap,settings,true,rect);CHECK(attempts==0);
        snap.localAlive=true;
    }
    {
        AimController controller(fakeKey,fakeSend,fakeNow);attempts=0;inputAccepted=false;fresh();
        controller.update(snap,settings,true,rect);CHECK(attempts==1);
        CHECK(controller.status().find("recusou")!=std::string::npos);
        inputAccepted=true;
    }
    {
        // Stop making corrections in the dead zone and damp a measured overshoot.
        AimController controller(fakeKey,fakeSend,fakeNow);settings.aimTarget=0;settings.aimStabilize=true;settings.aimDeadzone=3;
        settings.aimGain=1;snap.players[0].bones[6].x=1.f;attempts=0;fresh();controller.update(snap,settings,true,rect);
        CHECK(attempts==1);LONG first=sentX;
        snap.players[0].bones[6].x=-1.f;fresh();controller.update(snap,settings,true,rect);
        CHECK(attempts==2 && sentX<0 && -sentX<=first/2+1);
        snap.players[0].bones[6].x=.01f;attempts=0;fresh();controller.update(snap,settings,true,rect);
        CHECK(attempts==0);
        snap.players[0].bones[6].x=1.f;
    }
    {
        // Hold the original target even when another becomes closer, then release it.
        AimController controller(fakeKey,fakeSend,fakeNow);settings.aimStabilize=true;settings.aimDeadzone=3;
        Player second=player;second.pawn=200;second.bones[6].x=-1.f;snap.players[0].bones[6].x=.5f;
        snap.players.push_back(second);attempts=0;fresh();controller.update(snap,settings,true,rect);
        CHECK(attempts==1 && sentX>0);
        snap.players[0].bones[6].x=1.f;snap.players[1].bones[6].x=-.2f;fresh();controller.update(snap,settings,true,rect);
        CHECK(attempts==2 && sentX>0);
        heldKey=0;fresh();controller.update(snap,settings,true,rect);
        heldKey=VK_RBUTTON;fresh();controller.update(snap,settings,true,rect);
        CHECK(attempts==3 && sentX<0);
        snap.players.pop_back();snap.players[0].bones[6].x=1.f;
    }
    {
        // Priority changes the selected target but still obeys FOV and stabilization.
        settings.aimTarget=0;settings.aimStabilize=false;settings.aimPriority=0;
        snap.localPlayer=Player{};snap.players[0].bones[6].x=.3f;snap.players[0].meters=60;
        Player nearer=player;nearer.pawn=200;nearer.bones[6].x=-.8f;nearer.meters=5;snap.players.push_back(nearer);
        AimController center(fakeKey,fakeSend,fakeNow);attempts=0;fresh();center.update(snap,settings,true,rect);CHECK(attempts==1&&sentX>0);
        settings.aimPriority=1;AimController closest(fakeKey,fakeSend,fakeNow);attempts=0;fresh();closest.update(snap,settings,true,rect);CHECK(attempts==1&&sentX<0);
        snap.players[1].bones[6].x=-3.f;AimController outside(fakeKey,fakeSend,fakeNow);attempts=0;fresh();outside.update(snap,settings,true,rect);CHECK(attempts==1&&sentX>0);
        snap.players[1].bones[6].x=-.8f;snap.players[1].ally=true;AimController teammate(fakeKey,fakeSend,fakeNow);attempts=0;fresh();teammate.update(snap,settings,true,rect);CHECK(attempts==1&&sentX>0);snap.players[1].ally=false;
        snap.localPlayer.reset();AimController unavailable(fakeKey,fakeSend,fakeNow);attempts=0;fresh();unavailable.update(snap,settings,true,rect);CHECK(attempts==0&&unavailable.status().find("indispon")!=std::string::npos);
        snap.localPlayer=Player{};snap.players[1].meters=std::numeric_limits<float>::quiet_NaN();AimController invalid(fakeKey,fakeSend,fakeNow);attempts=0;fresh();invalid.update(snap,settings,true,rect);CHECK(attempts==1&&sentX>0);
        settings.aimStabilize=true;snap.players[1].meters=5;AimController locked(fakeKey,fakeSend,fakeNow);attempts=0;fresh();locked.update(snap,settings,true,rect);CHECK(attempts==1&&sentX<0);
        snap.players[0].meters=1;fresh();locked.update(snap,settings,true,rect);CHECK(attempts==2&&sentX<0);
        snap.players.pop_back();snap.players[0].bones[6].x=1.f;snap.players[0].meters=0;snap.localPlayer.reset();settings.aimPriority=0;
    }
    {
        // Track the first shot so the next increase in recoil is corrected.
        AimController controller(fakeKey,fakeSend,fakeNow);settings.aimEnabled=false;settings.recoilEnabled=true;
        snap.recoilReady=true;snap.shots=1;snap.punch={.5f,0,0};heldKey=VK_LBUTTON;
        attempts=0;fresh();controller.update(snap,settings,true,rect);CHECK(attempts==0);
        snap.shots=2;snap.punch={1.f,0,0};fresh();controller.update(snap,settings,true,rect);
        CHECK(attempts==1 && sentY<0);
        settings.aimEnabled=true;settings.recoilEnabled=false;snap.recoilReady=false;heldKey=VK_RBUTTON;
    }
    {
        AimController controller(fakeKey,fakeSend,fakeNow);attempts=0;settings.aimRadius=10;fresh();
        controller.update(snap,settings,true,rect);CHECK(attempts==0);
        CHECK(controller.status().find("FOV")!=std::string::npos);
    }
    std::puts("PASS: aim controller validation");
}
