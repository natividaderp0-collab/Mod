#include "../src/preview_data.hpp"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
using namespace crimson;
int main(){
    Snapshot s;uint64_t selected=0;
    Player a;a.pawn=1;a.hasBones=true;a.meters=20;
    Player b;b.pawn=2;b.hasBones=true;b.meters=10;
    Player ally;ally.pawn=3;ally.hasBones=true;ally.ally=true;ally.meters=5;
    s.players={a,b,ally};
    assert(preview::select(s,0,selected)==nullptr && selected==0);
    s.ready=true;assert(preview::select(s,0,selected)->pawn==2 && selected==2);
    s.players[0].meters=1;assert(preview::select(s,0,selected)->pawn==2);
    s.players[1].hasBones=false;assert(preview::select(s,0,selected)->pawn==1 && selected==1);
    selected=0;assert(preview::select(s,1,selected)->pawn==3);
    selected=0;assert(preview::select(s,2,selected)==nullptr);
    s.localPlayer=ally;assert(preview::select(s,2,selected)->pawn==3);
    s.localPlayer->hasBones=false;assert(preview::select(s,2,selected)==nullptr);
    using Status=preview::Status;
    auto now=std::chrono::steady_clock::time_point(std::chrono::seconds(10));
    s.connected=false;assert(preview::inspect(s,0,selected,now).status==Status::disconnected);
    s.connected=true;s.ready=false;assert(preview::inspect(s,0,selected,now).status==Status::notReady);
    s.ready=true;s.sampled={};assert(preview::inspect(s,0,selected,now).status==Status::stale);
    s.sampled=now-std::chrono::milliseconds(500);assert(preview::inspect(s,0,selected,now).status==Status::stale);
    s.sampled=now-std::chrono::milliseconds(499);assert(preview::inspect(s,0,selected,now).status==Status::poseReady);
    s.localPlayer.reset();assert(preview::inspect(s,2,selected,now).status==Status::noLocalPlayer);
    s.localPlayer=ally;s.localPlayer->hasBones=false;assert(preview::inspect(s,2,selected,now).status==Status::noBones);
    s.localPlayer->hasBones=true;assert(preview::inspect(s,2,selected,now).status==Status::poseReady);
    s.players.clear();assert(preview::inspect(s,0,selected,now).status==Status::noPlayer);
    s.players.push_back(a);s.players[0].hasBones=false;assert(preview::inspect(s,0,selected,now).status==Status::noBones);
    assert(preview::inspect(s,1,selected,now).status==Status::noPlayer);
}
