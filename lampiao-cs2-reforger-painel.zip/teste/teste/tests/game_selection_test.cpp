#include "../src/game_selection.hpp"
#include <cstdio>

using namespace games;
int main() {
    int failures = 0;
    auto check = [&](bool value, const char* name) { if (!value) { std::printf("FAIL: %s\n", name); ++failures; } };
    Detection none{};
    check(active(Preference::Automatic, none) == Game::CS2, "detection error retains CS2");
    none.available = true;
    check(active(Preference::Automatic, none) == Game::CS2, "no games retains CS2");
    Detection result{}; result.available = true;
    classify(L"ARMAREFORGERSTEAM.EXE", result);
    classify(L"unrelated.exe", result);
    check(result.reforger && !result.cs2, "case insensitive detection");
    check(active(Preference::Automatic, result) == Game::Reforger, "automatic reforger");
    check(active(Preference::CS2, result) == Game::CS2, "manual CS2 overrides");
    classify(L"Cs2.Exe", result);
    check(result.reforger && result.cs2, "both games detected");
    check(active(Preference::Automatic, result) == Game::CS2, "automatic prioritizes CS2");
    check(active(Preference::Reforger, result) == Game::Reforger, "manual reforger overrides");
    result.reforger = false;
    check(active(Preference::Automatic, result) == Game::CS2, "automatic cs2");
    check(active(Preference::Reforger, result) == Game::Reforger, "manual reforger while absent");
    auto real = detect();
    check(real.available || real.error != ERROR_SUCCESS, "detection result reports errors");
    if (!failures) std::puts("game selection tests passed");
    return failures ? 1 : 0;
}
