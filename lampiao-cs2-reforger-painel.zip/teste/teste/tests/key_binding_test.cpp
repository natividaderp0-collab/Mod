#include "../src/key_binding.hpp"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <array>
#include <cassert>
using namespace crimson;
static std::array<bool,255> pressed{};
static SHORT WINAPI fakeKey(int vk){return vk>=1 && vk<=254 && pressed[vk]?static_cast<SHORT>(0x8000):0;}
int main(){
    KeyBindingCapture capture;int key=VK_RBUTTON;
    // Ignore the click which started capture until all inputs are released.
    pressed[VK_LBUTTON]=true;capture.begin();assert(!capture.poll(true,fakeKey,key));assert(key==VK_RBUTTON);
    pressed.fill(false);assert(!capture.poll(true,fakeKey,key));
    pressed['K']=true;assert(capture.poll(true,fakeKey,key));assert(key=='K' && !capture.active);
    // A focused window is required and keys held on return must be released.
    pressed.fill(false);capture.begin();assert(!capture.poll(false,fakeKey,key));
    pressed['Q']=true;assert(!capture.poll(true,fakeKey,key));
    pressed.fill(false);assert(!capture.poll(true,fakeKey,key));
    pressed[VK_XBUTTON2]=true;assert(capture.poll(true,fakeKey,key));assert(key==VK_XBUTTON2);
    // The cancel button's mouse-down must not assign mouse left.
    pressed.fill(false);capture.begin();assert(!capture.poll(true,fakeKey,key));
    capture.ignoreLeft=true;pressed[VK_LBUTTON]=true;assert(!capture.poll(true,fakeKey,key));
    capture.cancel();assert(!capture.active && key==VK_XBUTTON2);
    // Left mouse and Escape can both be assigned outside the cancel button.
    pressed.fill(false);capture.begin();assert(!capture.poll(true,fakeKey,key));
    pressed[VK_LBUTTON]=true;assert(capture.poll(true,fakeKey,key));assert(key==VK_LBUTTON);
    pressed.fill(false);capture.begin();assert(!capture.poll(true,fakeKey,key));
    pressed[VK_ESCAPE]=true;assert(capture.poll(true,fakeKey,key));assert(key==VK_ESCAPE);
    // Prefer a specific modifier when Windows also reports its generic key.
    pressed.fill(false);capture.begin();assert(!capture.poll(true,fakeKey,key));
    pressed[VK_CONTROL]=pressed[VK_LCONTROL]=true;assert(capture.poll(true,fakeKey,key));assert(key==VK_LCONTROL);
    assert(!shortcutAvailable(true,false,true,'K',VK_END));
    assert(!shortcutAvailable(false,true,true,VK_END,VK_END));
    assert(shortcutAvailable(false,false,true,VK_END,VK_END));
    assert(shortcutAvailable(false,true,false,VK_END,VK_END));
    assert(shortcutAvailable(false,true,true,'K',VK_END));
    assert(legacyAimKeyToVk(0)==VK_RBUTTON && legacyAimKeyToVk(1)==VK_LBUTTON && legacyAimKeyToVk(2)==VK_MENU);
}
