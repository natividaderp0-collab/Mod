#include "../src/radar.hpp"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
#include <cmath>
#include <limits>
#include <optional>
#include <vector>
using namespace crimson;
struct Vec {float x{},y{},z{};};
struct Player {Vec origin{};bool ally{};};
struct Snapshot {bool ready{},localAlive{};std::optional<Player> localPlayer;std::vector<Player> players;std::chrono::steady_clock::time_point sampled{};};
int main(){
    Vec origin{},right{1000,0,0},up{0,1000,0};
    auto a=radar::project(origin,right,50,100);assert(a && std::abs(a->x-50.8f)<.01f && a->y==0);
    auto b=radar::project(origin,up,50,100);assert(b && b->y<0);
    assert(!radar::project(origin,right,25,100));
    assert(radar::project(origin,right,25.4f,100));
    assert(!radar::project(origin,right,0,100));
    Vec bad{std::numeric_limits<float>::quiet_NaN(),0,0};assert(!radar::project(origin,bad,50,100));
    using Clock=std::chrono::steady_clock;auto now=Clock::time_point(std::chrono::seconds(10));
    Snapshot s;s.ready=true;s.localAlive=true;s.localPlayer=Player{};s.sampled=now;
    s.players={Player{right,false},Player{up,true},Player{Vec{9000,0,0},false},Player{bad,false}};
    auto all=radar::markers(s,50,100,true,true,now);assert(all.size()==2&&!all[0].ally&&all[1].ally);
    assert(radar::markers(s,50,100,true,false,now).size()==1);
    assert(radar::markers(s,50,100,false,true,now).size()==1);
    assert(radar::markers(s,50,100,false,false,now).empty());
    assert(radar::available(s,now+std::chrono::milliseconds(499)));
    assert(!radar::available(s,now+std::chrono::milliseconds(500)));
    assert(!radar::available(s,now-std::chrono::milliseconds(1)));
    s.localAlive=false;assert(radar::markers(s,50,100,true,true,now).empty());
    s.localAlive=true;s.localPlayer.reset();assert(!radar::available(s,now));
}
