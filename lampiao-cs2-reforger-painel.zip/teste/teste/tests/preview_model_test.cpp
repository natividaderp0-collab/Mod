#include "../src/preview_model.hpp"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
#include <cmath>
#include <limits>
using namespace crimson::preview3d;
int main(){
    Joints b=example();Scene a;assert(project(b,300,450,a));
    assert(a.faces.size()>100 && a.top<a.joints[6].y && a.joints[6].y<a.joints[0].y && a.joints[0].y<a.joints[24].y);
    auto moving=b;moving[10].z+=18;moving[10].y+=8;Joints live;Scene changed;
    assert(orient(moving,live));assert(project(live,300,450,changed));
    assert(std::abs(changed.joints[10].y-a.joints[10].y)>10);
    bool depthsDiffer=false;float first=a.faces.front().depth;
    for(size_t i=1;i<a.faces.size();++i){assert(a.faces[i-1].depth>=a.faces[i].depth);depthsDiffer|=std::abs(a.faces[i].depth-first)>.1f;}
    assert(depthsDiffer);
    for(const auto& f:a.faces)for(const auto& p:f.points)assert(std::isfinite(p.x)&&std::isfinite(p.y)&&p.x>=0&&p.x<=300&&p.y>=0&&p.y<=450);
    Scene small;assert(!project(b,50,100,small));assert(project(b,600,600,small));
    auto shifted=b;for(auto& v:shifted){v.x+=1000;v.y-=500;v.z+=100;}
    Joints oriented,orientedShifted;assert(orient(b,oriented));assert(orient(shifted,orientedShifted));
    for(int i:used)assert(std::abs(oriented[i].x-orientedShifted[i].x)<.001f && std::abs(oriented[i].z-orientedShifted[i].z)<.001f);
    auto turned=b;for(auto& v:turned){float x=v.x;v.x=-v.y;v.y=x;}
    Joints rotated;assert(orient(turned,rotated));
    for(int i:used)assert(std::abs(oriented[i].x-rotated[i].x)<.001f && std::abs(oriented[i].y-rotated[i].y)<.001f);
    b[6].z=std::numeric_limits<float>::quiet_NaN();assert(!orient(b,oriented));assert(!project(b,300,450,a));
}
