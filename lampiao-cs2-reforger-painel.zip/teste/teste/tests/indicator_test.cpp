#include "../src/indicator.hpp"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <array>
#include <cassert>
#include <cmath>
#include <limits>
struct Vec {float x{},y{},z{};};
using namespace crimson::indicator;
int main(){
    std::array<float,16> m={1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1};Arrow a;
    assert(!offscreen(Vec{0,0,0},m,1920,1080,a));
    assert(!offscreen(Vec{1,1,0},m,1920,1080,a));
    assert(offscreen(Vec{2,0,0},m,1920,1080,a));assert(a.tip.x>1800 && std::abs(a.tip.y-540)<.01f && a.left.x<a.tip.x);
    assert(offscreen(Vec{-2,0,0},m,1920,1080,a));assert(a.tip.x<100 && a.left.x>a.tip.x);
    assert(offscreen(Vec{0,2,0},m,1920,1080,a));assert(a.tip.y<100 && a.left.y>a.tip.y);
    assert(offscreen(Vec{2,-2,0},m,1920,1080,a));assert(a.tip.x<1920 && a.tip.y<1080);
    assert(offscreen(Vec{99999,0,0},m,1920,1080,a));
    m[15]=-1;assert(!offscreen(Vec{2,0,0},m,1920,1080,a));m[15]=1;
    m[0]=std::numeric_limits<float>::quiet_NaN();assert(!offscreen(Vec{2,0,0},m,1920,1080,a));m[0]=1;
    assert(!offscreen(Vec{std::numeric_limits<float>::infinity(),0,0},m,1920,1080,a));
    assert(!offscreen(Vec{2,0,0},m,30,30,a));
}
