#include "../src/aim_math.hpp"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
#include <array>
#include <cmath>
#include <limits>
using namespace crimson::aim;
int main() {
    struct Position { float x{}, y{}, z{}; };
    std::array<Position,28> bones{}; bones[6]={1,2,70};bones[5]={1,2,63};bones[4]={1,2,52};
    Position head{1,2,70};
    assert(targetPosition(head,bones,true,0).z==70);
    assert(targetPosition(head,bones,true,1).z==63);
    assert(targetPosition(head,bones,true,2).z==52);
    assert(targetPosition(head,bones,false,0).z==70);
    assert(targetPosition(head,bones,false,1).z==63);
    assert(targetPosition(head,bones,false,2).z==52);
    assert(targetPosition(head,bones,true,99).z==70);
    AxisDamping damping;
    assert(damping.update(30,3)==1.f);
    assert(damping.update(-30,3)==.5f);
    assert(damping.update(-20,3)==.5f);
    assert(damping.update(2,3)==0.f);
    assert(damping.update(-20,3)==.5f);
    damping.reset();assert(damping.update(-20,3)==1.f);
    // Simulated gain > 1 overshoots initially; damping should settle near the target.
    AxisDamping feedback;float error=100.f;
    for(int i=0;i<20;++i)error-=error*2.f*.7f*feedback.update(error,3.f);
    assert(std::abs(error)<=3.f);
    assert(inRadius({960,540},1920,1080,100));
    assert(inRadius({1060,540},1920,1080,100));
    assert(!inRadius({1061,540},1920,1080,100));
    assert(!inRadius({-1,540},1920,1080,2000));
    assert(!inRadius({std::numeric_limits<float>::quiet_NaN(),540},1920,1080,100));
    auto center=mouseMove({960,540},1920,1080,1,1,2,8);
    assert(center.x==0 && center.y==0);
    auto right=mouseMove({1000,540},1920,1080,1,1,2,8);
    auto left=mouseMove({920,540},1920,1080,1,1,2,8);
    assert(right.x>0 && left.x<0 && std::abs(right.x+left.x)<0.001f);
    auto immediate=mouseMove({1200,540},1920,1080,1,1,2,1);
    assert(immediate.x > 80 && immediate.x < 2048);
    auto gain1=mouseMove({1000,540},1920,1080,1,1,2,8,1);
    auto gain2=mouseMove({1000,540},1920,1080,1,1,2,8,2);
    assert(std::abs(gain2.x-2*gain1.x)<0.001f);
    assert(mouseMove({1000,540},1920,1080,1,1,2,8,0).x==0);
    assert(mouseMove({1000,540},1920,1080,1,1,2,8,std::numeric_limits<float>::infinity()).x==0);
    assert(mouseMove({1920,540},1920,1080,1,1,.1f,1,12).x==2048);
    auto slow=mouseMove({1000,540},1920,1080,1,1,2,16);
    assert(std::abs(slow.x*2-right.x)<0.001f);
    assert(mouseMove({1000,540},1920,1080,1,1,0,1).x==0);
    auto recoil=recoilMove({1,2},{1.1f,2.1f},2,1);
    assert(recoil.x<0 && recoil.y<0 && std::abs(recoil.x-recoil.y)<0.001f);
    assert(recoilMove({1,2},{1,2},2,1).x==0);
}
